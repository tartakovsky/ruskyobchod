# Match media files to products by filename analysis

**Date:** 2026-02-24 21:00
**Task:** Write a Python script that matches WordPress media files to products by analyzing transliterated Russian filenames

## Goal
Find additional product-image matches beyond the 206 already in image_assignments.json by comparing media filenames (transliterated Russian) against product names (Slovak + Russian).

## Approach

### Step-by-step plan
1. Write `match_by_filename.py` with:
   - Multi-variant Russian-to-Latin transliteration (я→ja/ya, х→h/kh, etc.)
   - Product name parsing: split Slovak/Russian parts, extract keywords >=3 chars
   - Media filename parsing: split by `-`, `_`, camelCase; skip uninformative files
   - Scoring: keyword overlap ratio, require >=2 matches AND score >=0.5
   - Deduplicate: each media file assigned to best-scoring product only
   - Skip already-assigned products
   - Output filename_assignments.json
2. Run the script and report results

## Risks & Edge Cases
- Transliteration variants may not cover all patterns in filenames
- Some filenames use abbreviated forms (ShG = Шоколадная Глазурь)
- Numbers in filenames (weights, volumes) may help or confuse matching

## Files to Modify
- `match_by_filename.py` — new script (create)
- `filename_assignments.json` — output (generated)
