# Custom Runtime Inventory

## Gastronom Language Switcher

- Path: `/Users/alexandertartakovsky/Projects/gastronom-migration/gastronom-lang-switcher.live-current.php`
- Risk: `low`
- Domains: `commerce, language, runtime-bootstrap`
- Lines: `1038`
- Functions: `22`
- Actions: `template_redirect, wp_body_open, wp_enqueue_scripts, wp_print_footer_scripts`
- Filters: `determine_locale, document_title_parts, gettext, locale, nav_menu_item_title, option_blogdescription, option_blogname, pre_get_document_title, rank_math/frontend/title, rank_math/opengraph/facebook/title, rank_math/opengraph/twitter/title, script_loader_tag, single_term_title, the_title, wc_stripe_elements_options, wcpay_elements_options, wcpay_locale, woocommerce_currency_symbol, woocommerce_get_breadcrumb, woocommerce_page_title, woocommerce_product_get_name, woocommerce_product_variation_get_name, wpseo_opengraph_title, wpseo_title, wpseo_twitter_title`
- Meta keys: `(none)`

## Gastronom Stock Fix

- Path: `/Users/alexandertartakovsky/Projects/gastronom-migration/plugins/gastronom-stock-fix/gastronom-stock-fix.php`
- Risk: `high`
- Domains: `commerce, dotypos, language, runtime-bootstrap, storefront-ui, weight-stock`
- Lines: `1783`
- Functions: `80`
- Actions: `add_meta_boxes, added_post_meta, admin_footer, admin_init, init, plugins_loaded, save_post_product, template_redirect, updated_post_meta, woocommerce_admin_order_data_after_order_details, woocommerce_before_calculate_totals, woocommerce_before_cart, woocommerce_cart_calculate_fees, woocommerce_checkout_create_order, woocommerce_checkout_create_order_line_item, woocommerce_checkout_order_processed, woocommerce_email, woocommerce_order_item_meta_end, woocommerce_order_status_cancelled, woocommerce_order_status_refunded, woocommerce_process_product_meta, woocommerce_product_options_general_product_data, woocommerce_product_set_stock, woocommerce_rest_insert_product_object, woocommerce_single_product_summary, wp_ajax_gastronom_confirm_weight, wp_footer, wp_head`
- Filters: `rest_endpoints, wc_order_statuses, woocommerce_add_to_cart_quantity, woocommerce_add_to_cart_validation, woocommerce_available_payment_gateways, woocommerce_can_reduce_order_stock, woocommerce_can_restore_order_stock, woocommerce_email_enabled_backorder, woocommerce_email_enabled_low_stock, woocommerce_email_enabled_no_stock, woocommerce_gateway_description, woocommerce_get_item_data, woocommerce_get_price_html, woocommerce_order_item_name, woocommerce_quantity_input_args, woocommerce_stock_amount`
- Meta keys: `_backorders, _stock`

## Rusky Commerce Adjustments

- Path: `/Users/alexandertartakovsky/Projects/gastronom-migration/mu-plugins/rusky-commerce-adjustments.php`
- Risk: `low`
- Domains: `commerce, language, storefront-ui, weight-stock`
- Lines: `264`
- Functions: `13`
- Actions: `woocommerce_after_shipping_rate, woocommerce_before_product_object_save, woocommerce_cart_calculate_fees, woocommerce_process_product_meta, woocommerce_product_options_general_product_data, wp_footer`
- Filters: `woocommerce_add_to_cart_quantity, woocommerce_add_to_cart_validation, woocommerce_cart_shipping_method_full_label, woocommerce_gateway_description, woocommerce_gateway_title, woocommerce_get_price_html, woocommerce_quantity_input_args, woocommerce_rest_product_schema, woocommerce_stock_amount, woocommerce_update_cart_validation`
- Meta keys: `(none)`

## Rusky Disable FAR Runtime

- Path: `/Users/alexandertartakovsky/Projects/gastronom-migration/mu-plugins/rusky-disable-far.php`
- Risk: `medium`
- Domains: `plugin-runtime-override`
- Lines: `23`
- Functions: `0`
- Actions: `(none)`
- Filters: `option_active_plugins`
- Meta keys: `(none)`

## Rusky Dotypos Maintenance

- Path: `/Users/alexandertartakovsky/Projects/gastronom-migration/mu-plugins/rusky-dotypos-maintenance.php`
- Risk: `low`
- Domains: `dotypos`
- Lines: `189`
- Functions: `5`
- Actions: `rest_api_init`
- Filters: `(none)`
- Meta keys: `(none)`

## Rusky Dotypos Stock Bridge

- Path: `/Users/alexandertartakovsky/Projects/gastronom-migration/mu-plugins/rusky-dotypos-stock-bridge.php`
- Risk: `medium`
- Domains: `commerce, dotypos, weight-stock`
- Lines: `180`
- Functions: `8`
- Actions: `(none)`
- Filters: `(none)`
- Meta keys: `(none)`

## Rusky Language Switcher Lite

- Path: `/Users/alexandertartakovsky/Projects/gastronom-migration/mu-plugins/rusky-language-switcher-lite.php`
- Risk: `low`
- Domains: `language, runtime-bootstrap`
- Lines: `250`
- Functions: `5`
- Actions: `init, template_redirect, wp_body_open, wp_enqueue_scripts`
- Filters: `(none)`
- Meta keys: `(none)`

## Rusky Order Language Helpers

- Path: `/Users/alexandertartakovsky/Projects/gastronom-migration/mu-plugins/rusky-order-language-helpers.php`
- Risk: `low`
- Domains: `language`
- Lines: `186`
- Functions: `18`
- Actions: `(none)`
- Filters: `(none)`
- Meta keys: `(none)`

## Rusky Order Page Language

- Path: `/Users/alexandertartakovsky/Projects/gastronom-migration/mu-plugins/rusky-order-page-language.php`
- Risk: `medium`
- Domains: `language, runtime-bootstrap, weight-stock`
- Lines: `321`
- Functions: `14`
- Actions: `(none)`
- Filters: `(none)`
- Meta keys: `(none)`

## Rusky Preorder Admin

- Path: `/Users/alexandertartakovsky/Projects/gastronom-migration/mu-plugins/rusky-preorder-admin.php`
- Risk: `medium`
- Domains: `commerce, dotypos, language, weight-stock`
- Lines: `398`
- Functions: `21`
- Actions: `(none)`
- Filters: `(none)`
- Meta keys: `_stock`

## Rusky Preorder Notifications

- Path: `/Users/alexandertartakovsky/Projects/gastronom-migration/mu-plugins/rusky-preorder-notifications.php`
- Risk: `low`
- Domains: `commerce, language, weight-stock`
- Lines: `216`
- Functions: `6`
- Actions: `(none)`
- Filters: `(none)`
- Meta keys: `(none)`

## Rusky Preorder Storefront

- Path: `/Users/alexandertartakovsky/Projects/gastronom-migration/mu-plugins/rusky-preorder-storefront.php`
- Risk: `low`
- Domains: `commerce, language, weight-stock`
- Lines: `306`
- Functions: `22`
- Actions: `(none)`
- Filters: `(none)`
- Meta keys: `(none)`

## Rusky Product Sorting

- Path: `/Users/alexandertartakovsky/Projects/gastronom-migration/mu-plugins/rusky-product-sorting.php`
- Risk: `low`
- Domains: `catalog-sorting, commerce, language`
- Lines: `100`
- Functions: `7`
- Actions: `save_post, woocommerce_new_product, woocommerce_update_product`
- Filters: `woocommerce_catalog_orderby, woocommerce_default_catalog_orderby, woocommerce_get_catalog_ordering_args`
- Meta keys: `(none)`

## Rusky Runtime Shim

- Path: `/Users/alexandertartakovsky/Projects/gastronom-migration/mu-plugins/rusky-runtime-shim.php`
- Risk: `medium`
- Domains: `plugin-runtime-override, runtime-bootstrap`
- Lines: `150`
- Functions: `8`
- Actions: `plugins_loaded, template_redirect`
- Filters: `option_active_plugins`
- Meta keys: `(none)`

## Rusky Shop Alias

- Path: `/Users/alexandertartakovsky/Projects/gastronom-migration/mu-plugins/rusky-shop-alias.php`
- Risk: `low`
- Domains: `runtime-bootstrap`
- Lines: `34`
- Functions: `0`
- Actions: `template_redirect`
- Filters: `(none)`
- Meta keys: `(none)`

## Rusky Shop Display

- Path: `/Users/alexandertartakovsky/Projects/gastronom-migration/mu-plugins/rusky-shop-display.php`
- Risk: `low`
- Domains: `commerce`
- Lines: `27`
- Functions: `2`
- Actions: `(none)`
- Filters: `loop_shop_columns, loop_shop_per_page, woocommerce_cart_contents_count`
- Meta keys: `(none)`

## Rusky Stock Normalization

- Path: `/Users/alexandertartakovsky/Projects/gastronom-migration/mu-plugins/rusky-stock-normalization.php`
- Risk: `medium`
- Domains: `commerce`
- Lines: `143`
- Functions: `10`
- Actions: `save_post_product`
- Filters: `(none)`
- Meta keys: `_backorders, _stock`

## Rusky Stock Policy

- Path: `/Users/alexandertartakovsky/Projects/gastronom-migration/mu-plugins/rusky-stock-policy.php`
- Risk: `medium`
- Domains: `commerce, dotypos`
- Lines: `208`
- Functions: `20`
- Actions: `(none)`
- Filters: `woocommerce_stock_amount`
- Meta keys: `_backorders, _stock`

## Rusky Storefront Messaging

- Path: `/Users/alexandertartakovsky/Projects/gastronom-migration/mu-plugins/rusky-storefront-messaging.php`
- Risk: `low`
- Domains: `commerce, language, storefront-ui`
- Lines: `72`
- Functions: `4`
- Actions: `woocommerce_before_cart, woocommerce_before_shop_loop, wp_footer`
- Filters: `(none)`
- Meta keys: `(none)`

## Rusky Weight Preorder

- Path: `/Users/alexandertartakovsky/Projects/gastronom-migration/mu-plugins/rusky-weight-preorder.php`
- Risk: `medium`
- Domains: `commerce, weight-stock`
- Lines: `501`
- Functions: `40`
- Actions: `(none)`
- Filters: `(none)`
- Meta keys: `_backorders, _stock`

