## Gastronom Lang Switcher Inventory And Next Cuts

### Baseline

- Live file: `wp-content/plugins/gastronom-lang-switcher/gastronom-lang-switcher.php`
- Current size: about 1184 lines
- Emergency stabilization already completed:
  - Elementor crash-path removed
  - sensitive runtime separated from public language rendering
  - `real-time-find-and-replace` removed from runtime through MU shim
  - temporary Dotypos REST/write surface removed
  - weighted product logic extracted to `mu-plugins/rusky-commerce-adjustments.php`

### What should remain in the language layer

These are still plausibly part of the plugin's core purpose:

1. Language selection and context detection
- `gls_current_lang_code`
- `gls_server_lang`
- `gls_has_wp_login_cookie`
- `gls_is_sensitive_runtime_context`
- URL generation for RU/SK switcher

2. Text localization helpers
- bilingual title splitting/localization
- static page title mapping
- menu label translation
- account/cart/checkout phrase localization

3. Public title/meta translation
- `option_blogname`
- `option_blogdescription`
- title filters
- SEO title normalization

4. Public HTML language post-processing
- feed title localization
- server-rendered/storefront normalization
- inactive language block stripping
- `template_redirect` buffer for public pages only

5. Public language UI
- style enqueue
- switcher injection

6. Language-sensitive payment locale tweaks
- WooPayments / Stripe locale alignment
- only on public non-sensitive runtime

### What is still not really a language concern

These are the remaining non-language blocks still inside the plugin:

1. Storefront merchandising banners
- free shipping banner
- frozen delivery notice
- footer credit

2. Product sorting/catalog behavior
- `_sort_sk` / `_sort_ru` generation
- custom alphabetical sort option
- default sort order
- catalog ordering args

3. Theme/layout/shop display behavior
- shop columns
- products per page

4. Cart behavior tweak
- cart contents count counts line items instead of quantity sum

### Risk classification for next cuts

#### Low risk

- footer credit
- free shipping banner
- frozen delivery notice

Reason:
- mostly display-only
- easy smoke test on homepage/category/cart
- does not affect editor bootstrap

#### Medium risk

- shop columns
- products per page
- cart item count behavior

Reason:
- impacts storefront behavior and UX
- not dangerous, but more visible and coupled to theme/cart expectations

#### Higher risk

- sorting key generation and alphabetical sort system

Reason:
- touches product save hooks
- can affect catalog ordering and Dotypos/product imports indirectly
- should be moved only after a dedicated inventory and verification pass

### Recommended next extraction order

1. Merchandising UI block
- free shipping banner
- frozen delivery notice
- footer credit

Target:
- move to a new MU/plugin surface such as `rusky-storefront-messaging.php`

Smoke:
- `/`
- one category page
- `?lang=ru`
- cart page
- Elementor preview

2. Layout/shop display block
- shop columns
- products per page
- cart count behavior

Target:
- separate MU/plugin surface such as `rusky-shop-display.php`

Smoke:
- shop page
- category page
- header cart count
- cart page

3. Sorting block
- `_sort_sk` / `_sort_ru`
- alphabetical sort option and args

Target:
- separate MU/plugin surface such as `rusky-product-sorting.php`

Smoke:
- product save
- imported product save path
- category sorting
- RU/SK alphabetical ordering

### Guardrails for future work

For every next live step:

1. One semantic block only
2. Backup before replace
3. New destination surface first
4. Then remove old block
5. Smoke immediately:
- `/`
- `?lang=ru`
- Elementor preview
- one commerce path touched by that block

### Decision

The next best cut is:

- extract merchandising UI block first

Reason:
- smallest remaining non-language surface
- highest architectural clarity gain per unit of risk
- does not touch imports, product saves, or editor/runtime bootstrap
