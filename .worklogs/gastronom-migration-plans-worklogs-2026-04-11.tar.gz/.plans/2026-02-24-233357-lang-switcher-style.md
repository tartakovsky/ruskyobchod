# Увеличить и сделать заметнее кнопку переключения языков

**Date:** 2026-02-24 23:33
**Task:** Обновить CSS кнопки RU/SK — сделать крупнее, добавить рамку, пульсацию

## Goal
Кнопка переключения языков должна быть заметнее и крупнее.

## Approach
1. Обновить .gls-switcher: padding, border, gap, box-shadow
2. Обновить .gls-btn: font-size, padding, border-radius
3. Добавить box-shadow на .gls-btn.active
4. Добавить @keyframes gls-pulse и применить к неактивной кнопке
5. Обновить mobile media query

## Files to Modify
- `gastronom-lang-switcher/gls-style.css` — все изменения в этом файле
