# Gastronom Stock Fix Owner Map

Date: 2026-04-11 10:36:08 +0200

## Purpose

This is the compact owner map for the remaining compatibility shell surface in:

- `plugins/gastronom-stock-fix/gastronom-stock-fix.php`

It answers one question only:

- which owner file now owns which `gastronom_*` wrapper family

## Owner Map

### `mu-plugins/rusky-stock-policy.php`

Owns:

- `gastronom_setup_decimal_stock_amount()`
- `gastronom_disable_stock_notifications()`
- `gastronom_disable_stock_email_actions()`
- `gastronom_detach_dotypos_product_updated_hook()`
- `gastronom_adjust_rest_endpoints_for_decimal_stock()`
- `gastronom_sync_stock_status_after_set_stock()`
- `gastronom_sync_stock_status_after_rest_insert()`
- `gastronom_reconcile_on_updated_post_meta()`
- `gastronom_reconcile_on_added_post_meta()`
- `gastronom_run_stock_fix_repair_once()`

### `mu-plugins/rusky-stock-normalization.php`

Owns:

- `gastronom_normalize_product_name()`
- `gastronom_catalog_policy()`
- `gastronom_reconcile_decimal_stock()`
- `gastronom_apply_catalog_policy()`
- `gastronom_enforce_product_rules()`

### `mu-plugins/rusky-commerce-adjustments.php`

Owns:

- `gastronom_add_cod_fee()`
- `gastronom_gateway_description()`
- `gastronom_render_checkout_payment_refresh_script()`

### `mu-plugins/rusky-order-language-helpers.php`

Owns:

- `gastronom_current_lang()`
- `gastronom_order_lang()`
- `gastronom_tt()`
- `gastronom_t()`
- `gastronom_locale_for_order()`
- `gastronom_with_order_locale()`
- `gastronom_split_bilingual_title()`
- `gastronom_localize_title()`
- `gastronom_localize_order_label()`

### `mu-plugins/rusky-weight-preorder.php`

Owns:

- `gastronom_weight_preorder_enabled()`
- `gastronom_weight_preorder_min_kg()`
- `gastronom_weight_preorder_max_kg()`
- `gastronom_weight_preorder_avg_kg()`
- `gastronom_weight_preorder_price_per_kg()`
- `gastronom_weight_preorder_reserved_qty()`
- `gastronom_weight_preorder_piece_capacity()`
- `gastronom_apply_preorder_piece_stock()`
- `gastronom_preorder_item_is_confirmed()`
- `gastronom_normalize_preorder_order_state()`
- `gastronom_product_has_preorder_weight()`
- `gastronom_order_has_preorder_weight()`
- `gastronom_order_requires_weight_confirmation()`
- `gastronom_reserve_preorder_site_stock()`
- `gastronom_restore_preorder_site_stock()`
- `gastronom_can_reduce_order_stock()`
- `gastronom_can_restore_order_stock()`
- `gastronom_prepare_checkout_processed_preorder()`
- `gastronom_register_await_weight_status()`
- `gastronom_inject_await_weight_status()`

### `mu-plugins/rusky-preorder-storefront.php`

Owns:

- `gastronom_quantity_input_args()`
- `gastronom_add_to_cart_quantity()`
- `gastronom_add_to_cart_validation()`
- `gastronom_before_calculate_totals()`
- `gastronom_get_item_data()`
- `gastronom_render_single_product_note()`
- `gastronom_render_cart_notice()`
- `gastronom_available_payment_gateways()`
- `gastronom_price_html()`
- `gastronom_checkout_create_order()`
- `gastronom_checkout_create_order_line_item()`

### `mu-plugins/rusky-preorder-notifications.php`

Owns:

- `gastronom_send_preorder_created_emails()`
- `gastronom_send_weight_confirmation_email()`
- `gastronom_mark_weight_confirmed_order_ready()`

### `mu-plugins/rusky-preorder-admin.php`

Owns:

- `gastronom_render_weight_confirmation_box()`
- `gastronom_order_screen_ids()`
- `gastronom_admin_footer_hook()`
- `gastronom_remove_hidden_meta_boxes()`
- `gastronom_render_inline_weight_panel()`
- `gastronom_handle_weight_confirmation_ajax()`

### `mu-plugins/rusky-dotypos-stock-bridge.php`

Owns:

- `gastronom_apply_dotypos_stock_to_wc_product()`
- `gastronom_resolve_dotypos_order_sync_quantity()`
- `gastronom_sync_confirmed_preorder_items_to_dotypos()`
- `gastronom_restore_confirmed_preorder_items_to_dotypos()`

### `mu-plugins/rusky-order-page-language.php`

Owns:

- `gastronom_get_context_order_for_frontend_language()`
- `gastronom_normalize_order_page_html()`
- `gastronom_localize_order_item_name()`
- `gastronom_render_forced_order_lang_marker()`
- `gastronom_maybe_redirect_context_order_lang()`
- `gastronom_start_order_page_buffer()`
- `gastronom_render_order_item_actual_weight()`

## Practical conclusion

The shell is now understandable by owner family.

Future cleanup should work from this map, not by reopening the monolith and rediscovering ownership from scratch.
