# Audit WooCommerce product tax classes against Slovak DPH rules

**Date:** 2026-03-17 22:06
**Task:** Check all 701 products for correct DPH rate assignment per 2026 Slovak rules

## Goal
Identify products with incorrect tax_class so user can fix them before going live.

## Approach

### Step-by-step plan
1. Write Python script to /tmp/audit_vat.py
2. Fetch all products via WC REST API (paginated, 100 per page)
3. Classify each product by name/category into 5%, 19%, or 23% DPH bracket
4. Compare against current tax_class assignment
5. Output grouped report of mismatches

## Risks & Edge Cases
- Product names are in Russian, need keyword matching in Russian
- Some products are ambiguous (e.g. "tvorог" could be fresh or processed)
- WC API pagination — need to fetch all pages
- The "ponizhennaya-stavka" class has both 5% and 19% rates — structural issue to flag

## Files to Modify
- `/tmp/audit_vat.py` — new script for the audit
