# Apply product images via WooCommerce API

**Date:** 2026-02-24 20:52
**Task:** Write and run a script to set product images on the new WooCommerce site using image_assignments.json

## Goal
All 206 products in image_assignments.json get their images set via WC REST API.

## Approach

### Step-by-step plan
1. Write `apply_images.py` that reads image_assignments.json
2. For each assignment, PUT to wc/v3/products/{id} with images payload
3. Rate limit 0.3s between requests, log progress every 10
4. Print summary at end
5. Run the script
6. Verify a few products via API to confirm images attached

## Files to Modify
- `apply_images.py` — new script
