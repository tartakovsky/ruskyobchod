# Gastronom Stock Fix Dotypos Write Surface

## Scope

This inventory is limited to:

- direct Dotypos stock mutations
- immediate post-mutation Woo sync
- hook-level behavior that changes whether vendor Dotypos sync runs

Source reviewed:

- `/Users/alexandertartakovsky/Projects/gastronom-migration/plugins/gastronom-stock-fix/gastronom-stock-fix.php`
- old handoff pack rules from `/Users/alexandertartakovsky/Downloads/handoff.zip`

## Current conclusion

Inside `gastronom-stock-fix.php`, the real Dotypos write surface is smaller than the file size suggests.

Direct cash mutations found: `2`

- confirmed preorder deduction
- confirmed preorder restore

Everything else found in this pass is either:

- Woo/site-side stock shaping
- guard logic that prevents premature Dotypos movement
- hook surgery affecting vendor sync behavior

## Direct Dotypos writes

### 1. Confirmed preorder deduction

Code path:

- function `gastronom_sync_confirmed_preorder_items_to_dotypos()`
- direct write at line `1166`
- called from the admin AJAX weight-confirmation flow at line `1910`

Behavior:

- iterates order line items
- only processes items marked `_gastronom_weight_preorder = yes`
- requires `_gastronom_weight_confirmed = yes`
- skips items already marked `_gastronom_weight_cash_synced = yes`
- requires a product-level Dotypos ID
- requires positive actual weight
- writes negative stock movement to Dotypos
- immediately fetches latest warehouse stock from Dotypos
- converts that raw kg stock into Woo preorder piece stock via `gastronom_apply_preorder_piece_stock()`
- marks the item `_gastronom_weight_cash_synced = yes`

Meaning:

- this is a delayed, manager-confirmed site -> cash deduction
- it is not part of ordinary checkout placement

### 2. Confirmed preorder restore

Code path:

- function `gastronom_restore_confirmed_preorder_items_to_dotypos()`
- direct write at line `1215`
- hooked to:
  - `woocommerce_order_status_cancelled`
  - `woocommerce_order_status_refunded`

Behavior:

- only processes preorder items
- requires `_gastronom_weight_cash_synced = yes`
- skips items already marked `_gastronom_weight_cash_restored = yes`
- requires a product-level Dotypos ID
- requires positive actual weight
- writes positive stock movement back to Dotypos
- immediately fetches latest warehouse stock from Dotypos
- reapplies preorder piece stock locally via `gastronom_apply_preorder_piece_stock()`
- marks the item `_gastronom_weight_cash_restored = yes`

Meaning:

- this is the cash restore side of the same delayed preorder model

## Dotypos-related guard surfaces

These do not write to Dotypos directly, but they materially change integration behavior.

### 1. Vendor product-update sync suppression

Code path:

- `plugins_loaded` block at lines `44-49`

Behavior:

- removes Dotypos plugin handler `handle_product_updated` from `woocommerce_update_product`

Meaning:

- this is a high-leverage integration override
- it changes whether product updates trigger vendor-side stock behavior
- it belongs in the future `rusky-dotypos-stock-bridge` extraction, not in a general junk-drawer plugin

### 2. Explicit “do not sync yet” quantity resolver

Code path:

- `gastronom_resolve_dotypos_order_sync_quantity()` at lines `547+`

Behavior:

- returns `false` for preorder-weight items
- the function intent is explicit: do not let variable-weight preorder items move Dotypos stock before manager confirmation

Current caveat:

- in the current local repo snapshot, this function is not referenced elsewhere by name
- that suggests one of these possibilities:
  - a server-only integration hook exists outside the repo snapshot
  - the function is planned but currently inactive
  - the vendor integration used to call it and no longer does

This ambiguity should be resolved before extraction.

### 3. Dotypos -> Woo preorder stock adapter

Code path:

- `gastronom_apply_dotypos_stock_to_wc_product()` at lines `533+`

Behavior:

- if the product is preorder-weight enabled, converts raw Dotypos kg stock into Woo preorder piece stock by calling `gastronom_apply_preorder_piece_stock()`

Current caveat:

- in the current local repo snapshot, this function is not referenced elsewhere by name
- same ambiguity applies as above

## Site-side preorder stock mechanics

These are not Dotypos writes, but they are tightly coupled to the delayed-confirmation model.

### Woo-only reserve path

- `gastronom_reserve_preorder_site_stock()`
- reduces local Woo `_stock` by reserved piece count at order placement
- does not touch Dotypos yet

### Woo-only restore path

- `gastronom_restore_preorder_site_stock()`
- restores local Woo `_stock` if the reservation must be returned
- does not touch Dotypos directly

### Woo local state after Dotypos write

- `gastronom_apply_preorder_piece_stock()`
- stores `_gastronom_cash_stock_kg`
- recalculates piece capacity
- updates Woo `_stock`, `_stock_status`, `_manage_stock`, `_backorders`

Meaning:

- the preorder model is intentionally two-phase:
  - reserve pieces locally first
  - move cash stock only after weight confirmation

## Extraction recommendation

The first safe Dotypos-related extraction target inside `gastronom-stock-fix.php` is not the entire preorder system.

It is this narrower bridge surface:

- vendor sync suppression
- delayed preorder deduction
- delayed preorder restore
- any real hook wiring for:
  - `gastronom_apply_dotypos_stock_to_wc_product()`
  - `gastronom_resolve_dotypos_order_sync_quantity()`

Suggested future destination:

- `mu-plugins/rusky-dotypos-stock-bridge.php`

## Preconditions before extraction

1. Confirm whether the two helper functions with Dotypos intent are actually live-wired anywhere on production.
2. Confirm whether live server code differs from this repo snapshot for Dotypos hook registration.
3. Keep the Woo-only preorder reservation logic separate from the Dotypos bridge extraction.
4. Do not re-enable general site -> cash sync as part of this extraction.

## Next hardening step

Do a second inventory pass for the preorder-weight state machine itself:

- order creation
- local piece reservation
- `await-weight` status transitions
- manager confirmation AJAX
- restore paths

That will define the extraction boundary for a future `rusky-weight-preorder.php`.
