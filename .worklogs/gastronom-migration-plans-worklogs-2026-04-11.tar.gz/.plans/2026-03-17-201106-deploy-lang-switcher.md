# Deploy gastronom-lang-switcher plugin to WordPress

**Date:** 2026-03-17 20:11
**Task:** Deploy updated lang-switcher plugin via WP REST API

## Goal
Replace the current plugin on the Hostinger site with the updated local version.

## Approach
1. Create ZIP of the plugin directory
2. Deactivate existing plugin via REST API
3. Delete existing plugin via REST API
4. Upload new ZIP via REST API
5. Activate plugin via REST API

## Files to Modify
- `/tmp/deploy_plugin.py` — deployment script (new, temporary)
