# Compare WooCommerce and Dotypos product lists

**Date:** 2026-03-15 20:09
**Task:** Find all discrepancies between WC and Dotypos CSV

## Goal
Produce complete lists of: products only in WC, only in Dotypos, and stock mismatches.

## Approach
1. Fetch all WC products via REST API (paginated)
2. Parse Dotypos CSV
3. Normalize names and match (exact + fuzzy)
4. Report all discrepancies

## Files to Modify
- None (read-only investigation)
