# Fix duplicate products, wrong categories, and bad SKUs

**Date:** 2026-03-15 23:06
**Task:** Delete 18 duplicate products, fix categories for 15 products, fix SKUs with commas

## Goal
Clean up WooCommerce catalog: remove duplicates, fix miscategorized products, fix malformed SKUs.

## Approach

### Step-by-step plan
1. Write Python script with 3 parts:
   - Part 1: DELETE 18 duplicate products (higher IDs) via WC REST API
   - Part 2: PUT category change for 15 products (196 -> 263)
   - Part 3: GET all products, find SKUs with commas, PUT to fix them
2. Run the script

## Files to Modify
- `fix_duplicates_categories.py` — new script for all 3 operations
