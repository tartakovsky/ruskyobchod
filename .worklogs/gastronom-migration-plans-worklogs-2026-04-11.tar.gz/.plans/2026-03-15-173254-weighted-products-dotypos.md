# Пометка весовых товаров по данным Dotypos POS

**Date:** 2026-03-15 17:32
**Task:** Установить чекбокс «Весовой товар» только для товаров с единицей Kilogram в Dotypos

## Goal
Все товары с единицей измерения «Kilogram» в кассе Dotypos должны иметь `_gls_weighted=yes` в WooCommerce.

## Approach
1. Сбросить _gls_weighted=no на всех товарах (ранее было 136 неверно помеченных)
2. Получить из Dotypos Admin список товаров с единицей Kilogram (сканирование таблицы + поиск)
3. Установить _gls_weighted=yes только на подтверждённых товарах (152 шт)

## Files to Modify
- Скрипт обновления через WC REST API batch endpoint
