# Fuzzy matching unmapped products to unmapped images

**Date:** 2026-02-24 23:25
**Task:** Match 306 products without images to 408 available images using fuzzy keyword matching

## Goal
Reduce the number of unmapped products by finding image matches based on product names (Slovak+Russian) vs image filenames/titles (Russian transliteration).

## Approach
1. Read both CSVs
2. Normalize text: lowercase, remove extensions, remove meaningless prefixes (hashes, photo_dates)
3. Extract keywords from product names (both Slovak and Russian parts) and image titles/filenames
4. Score each product-image pair based on keyword overlap
5. Require >= 2 keyword matches and score >= 0.4
6. Output three files: mapped, remaining unmapped products, remaining unmapped images

## Files to Modify
- `match_products_images.py` — new script
- `products_unmapped.csv` — overwrite with remaining unmapped
- `images_unmapped.csv` — overwrite with remaining unmapped
- `products_images_mapped.csv` — new file with matches
