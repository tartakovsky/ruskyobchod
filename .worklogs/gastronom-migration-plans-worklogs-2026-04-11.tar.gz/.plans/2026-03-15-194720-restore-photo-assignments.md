# Restore photo assignments to WooCommerce products

**Date:** 2026-03-15 19:47
**Task:** Restore product images using saved mapping file

## Goal
All 603 products with images in the mapping file should have their images restored via WC REST API.

## Approach

### Step-by-step plan
1. Read photo_mapping_2026-03-14.json
2. Filter products that have images
3. For each product, prepare update payload with `{"id": wc_id, "images": [{"id": image_id}]}`
4. Send in batches of 50 via POST /wp-json/wc/v3/products/batch
5. Track success/failure counts
6. Verify a few products at the end

## Risks & Edge Cases
- Some image IDs might no longer exist in media library — API may error
- Rate limiting on Hostinger
- Batch size of 50 should be safe for WC API

## Files to Modify
- `restore_photos.py` — new script to run the restoration
