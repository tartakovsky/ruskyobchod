# Runtime Ownership Map

## Ownership rules

These are the current allowed ownership boundaries after the first hardening cuts.

- `mu-plugins/rusky-runtime-shim.php`
  Owns runtime plugin overrides and guarded FAR HTML rewriting.
  This is the only file allowed to filter `option_active_plugins`.
  It may block:
  - `real-time-find-and-replace` globally
  - `gastronom-lang-switcher` only for sensitive runtime or logged-in non-admin paths

- `gastronom-lang-switcher.live-current.php`
  Owns public language detection, title/text localization, switcher UI, and public non-sensitive language presentation.
  It must not own runtime plugin activation policy.

- `mu-plugins/rusky-storefront-messaging.php`
  Owns storefront-only banners and footer merchandising copy.
  It must not touch product save hooks, plugin runtime, or stock state.

- `mu-plugins/rusky-shop-display.php`
  Owns shop columns, per-page limits, and cart count presentation.
  It must not touch runtime bootstrap or product persistence.

- `mu-plugins/rusky-product-sorting.php`
  Owns catalog sorting metadata and ordering arguments.
  It may touch product save hooks, but it must not own storefront messaging or runtime overrides.

- `mu-plugins/rusky-commerce-adjustments.php`
  Owns the extracted lightweight decimal quantity and weighted-product storefront behavior.
  It must not mutate Dotypos directly.

- `plugins/gastronom-stock-fix/gastronom-stock-fix.php`
  Still owns the remaining high-risk mixed stock, Dotypos, preorder-weight, admin, and email logic.
  This is the next major extraction surface and should be reduced in semantic slices, not rewritten wholesale.

## Invariants

- `option_active_plugins` has one owner only: `mu-plugins/rusky-runtime-shim.php`
- FAR runtime behavior has one owner only: `mu-plugins/rusky-runtime-shim.php`
- Storefront messaging has one owner only: `mu-plugins/rusky-storefront-messaging.php`
- Shop display tuning has one owner only: `mu-plugins/rusky-shop-display.php`
- Catalog sorting has one owner only: `mu-plugins/rusky-product-sorting.php`

## Next hardening target

The next architectural target remains `plugins/gastronom-stock-fix/gastronom-stock-fix.php`.

Recommended order:

1. inventory and isolate Dotypos mutation entry points
2. inventory and isolate `_gastronom_weight_preorder` flows
3. split one semantic block at a time into dedicated MU/plugin surfaces
