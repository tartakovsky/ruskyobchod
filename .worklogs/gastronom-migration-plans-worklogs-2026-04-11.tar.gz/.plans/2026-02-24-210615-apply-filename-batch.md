# Apply second batch of image assignments (filename_assignments.json)

**Date:** 2026-02-24 21:06
**Task:** Apply 118 product image assignments from filename_assignments.json via WooCommerce REST API

## Goal
Assign images to 118 products on the new WooCommerce site using the filename-based matching results.

## Approach

### Step-by-step plan
1. Modify `apply_images.py` to accept the input file as a command-line argument (default: `image_assignments.json`)
2. Run the script with `filename_assignments.json` as input
3. Verify a few products via GET API to confirm images are attached

## Risks & Edge Cases
- Some products may already have images from batch 1 — the PUT replaces all images, so no conflict
- Rate limiting at 0.3s should be fine for 118 requests (~35 seconds total)
- SSL verification disabled for staging site

## Files to Modify
- `apply_images.py` — add CLI argument for input file path
