# Architecture Hardening Plan

## Current conclusion

The production site is no longer blocked by the immediate Elementor/runtime failure, but the custom runtime is still fragile because business logic is split across too many surfaces with unclear boundaries.

The biggest remaining source of fragility is not the language layer anymore.
It is the combination of:

- `gastronom-stock-fix`
- runtime plugin overrides around FAR / logged-in requests
- two parallel weight-product models

## High-risk findings

### 1. `gastronom-stock-fix` is still a junk drawer

File:

- `/Users/alexandertartakovsky/Projects/gastronom-migration/plugins/gastronom-stock-fix/gastronom-stock-fix.php`

Why it is risky:

- ~1900 lines
- mixes stock mechanics, Dotypos sync, weight preorder, admin UI, order status logic, payment behavior, storefront output, localization helpers and email behavior
- contains both WooCommerce stock hooks and direct Dotypos stock mutations
- contains admin AJAX for weight confirmation
- contains frontend rendering and language-aware helpers

This is the current highest-risk custom file.

### 2. Two weight models exist at the same time

Current models:

- `_gls_weighted` in `rusky-commerce-adjustments.php`
- `_gastronom_weight_preorder` in `gastronom-stock-fix.php`

Why this is risky:

- both affect quantity behavior
- they use different stock semantics
- only one of them is connected to delayed Dotypos deduction after weight confirmation
- this makes future sync logic easy to misapply

### 3. Runtime plugin override logic is split across two MU plugins

Files:

- `/Users/alexandertartakovsky/Projects/gastronom-migration/mu-plugins/rusky-disable-far.php`
- `/Users/alexandertartakovsky/Projects/gastronom-migration/mu-plugins/rusky-runtime-shim.php`

Why this is risky:

- both touch `option_active_plugins`
- one disables FAR globally
- the other conditionally disables FAR and also conditionally disables `gastronom-lang-switcher`
- this is operationally effective, but architecturally easy to misunderstand later

### 4. Language helpers still exist outside the language plugin

`gastronom-stock-fix` still contains:

- current language detection
- order-localized text helpers
- bilingual title splitting/localization

This is survivable today, but creates duplication and future drift.

## Safe cleanup order

### Phase 1: Documentation and invariants

Do first, before more prod edits:

1. maintain a runtime ownership map
2. define one truth for each concern:
   - language
   - storefront messaging
   - catalog sorting
   - stock normalization
   - weight preorder
   - Dotypos sync
3. define which files are allowed to mutate Dotypos
4. define which files are allowed to touch `option_active_plugins`

This phase is safe and should happen first.

### Phase 2: Unify runtime override ownership

Target:

- replace the current two-file FAR/runtime override arrangement with one clearly named MU plugin

Goal:

- one file owns:
  - disabling FAR at runtime
  - narrowing risky public HTML rewrites
  - logged-in / Elementor safety bypasses

Benefits:

- less hidden interaction
- easier rollback
- easier future debugging when logged-in and anonymous behavior differ

Risk:

- medium, because it touches bootstrap and plugin loading

### Phase 3: Separate `gastronom-stock-fix` by responsibility

Do not rewrite it wholesale on production.
Split it by semantic block.

Recommended split targets:

1. `rusky-stock-normalization.php`
   - decimal stock support
   - `_stock_status` reconciliation
   - REST schema adjustments for decimal quantities

2. `rusky-weight-preorder.php`
   - preorder-by-piece / confirm-weight-later model
   - order status `await-weight`
   - reserve / restore site stock
   - admin confirmation box

3. `rusky-dotypos-stock-bridge.php`
   - Dotypos stock mutation logic only
   - only for allowed flows
   - explicit feature flag / setting checks

4. `rusky-store-policy.php`
   - service / seasonal catalog policy
   - low stock email suppression if still desired

Benefits:

- no single file mixes storefront, admin, stock, Dotypos and translation behavior
- easier smoke testing
- rollback becomes per-block instead of all-or-nothing

Risk:

- high if attempted as one deploy
- manageable if done one block at a time

### Phase 4: Unify the weight model

This is essential before re-enabling any site -> cash sync.

Desired outcome:

- one canonical weight mechanism only
- explicit distinction:
  - ordinary decimal-stock goods
  - preorder-by-piece / confirm-weight-later goods

Likely direction:

- keep `_gastronom_weight_preorder` for the delayed-confirmation flow
- review whether `_gls_weighted` should remain only for simple decimal quantity products or be renamed and documented
- no hidden overlap between the two

### Phase 5: Rebuild pre-sync operational discipline

Before any cash resync:

1. all suspicious products reviewed
2. weight-preorder products verified end-to-end
3. unmapped/service/seasonal products classified
4. one-way cash -> site reconciliation only
5. only after successful verification allow site -> cash stock deduction

## Immediate safe tasks

These can be done with minimal production risk:

1. write and keep the runtime ownership map
2. produce and review the suspicious-products workbook
3. classify unmapped products into:
   - service
   - seasonal
   - valid catalog product needing mapping
4. inspect the 3 live preorder-weight products in detail
5. prepare a single-source runtime shim design before touching production files

## Things to avoid

Do not do these as a “cleanup” shortcut:

- no direct `active_plugins` DB editing
- no blind Dotypos writeback
- no large rewrite of `gastronom-stock-fix` in one deploy
- no mixed architecture cleanup + sync re-enable in one window
- no assumption that all decimal-stock items are preorder-weight items

## Recommended next implementation order

1. classify suspicious products from the Excel review
2. audit the 3 live preorder-weight products
3. design the merged runtime override MU plugin locally
4. deploy runtime-override simplification with rollback
5. only then begin semantic extraction from `gastronom-stock-fix`
