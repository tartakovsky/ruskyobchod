# Регистрация домена gastronom-bratislava.sk

**Date:** 2026-03-16 23:15
**Task:** Зарегистрировать домен gastronom-bratislava.sk на словацком регистраторе

## Goal
Зарегистрировать домен .sk для будущего перехода магазина с ruskyobchod.sk

## Approach
1. Сравнить цены словацких регистраторов (Websupport, Active24, FORPSI, Exohosting)
2. Выбрать регистратора
3. Оформить заказ и оплатить

## Files to Modify
- Memory: обновить информацию о домене
