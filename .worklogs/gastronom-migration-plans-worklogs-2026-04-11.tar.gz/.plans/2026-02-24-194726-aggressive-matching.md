# Rewrite match_images.py with aggressive matching

**Date:** 2026-02-24 19:47
**Task:** Improve product matching from 91/450 to as many as possible

## Goal
Match old site products to new site products using bilingual name splitting, aggressive normalization (remove units, punctuation, brands), and multi-strategy matching (exact, fuzzy, word-overlap).

## Approach

### Step-by-step plan
1. Rewrite `split_bilingual_name` to handle both `/` and `. ` separators, plus script-boundary detection
2. Add aggressive normalization: remove weight units (г, гр, g, kg, ml, l etc.), remove brand text in «», strip all punctuation
3. Implement 7 matching strategies in order: exact slug, exact normalized RU, exact normalized SK, fuzzy RU (0.75), fuzzy SK (0.75), fuzzy full (0.70), word-overlap (70%)
4. Generate 3 output files: image_assignments.json, match_report.txt, still_unmatched.json (with top-3 candidates)
5. Run and report results

## Files to Modify
- `match_images.py` — full rewrite of matching logic
