# Gastronom Stock Fix Shell State

Date: 2026-04-11 10:31:29 +0200

## Current state

`plugins/gastronom-stock-fix/gastronom-stock-fix.php` is no longer acting like a mixed-ownership implementation file.

At this point it is primarily:

- compatibility wrappers
- named hook wiring
- fallback definitions guarded by `if (!function_exists(...))`

## Observable signals

- current diff against the working tree shows the file has already shrunk materially:
  - `541` inserted lines
  - `672` deleted lines
- the remaining `gastronom_*` function count is still high because the file is now mostly a compatibility shell, not because it still owns all underlying logic
- the main semantic ownership has been pushed into:
  - `mu-plugins/rusky-stock-policy.php`
  - `mu-plugins/rusky-stock-normalization.php`
  - `mu-plugins/rusky-order-language-helpers.php`
  - `mu-plugins/rusky-order-page-language.php`
  - `mu-plugins/rusky-weight-preorder.php`
  - `mu-plugins/rusky-preorder-storefront.php`
  - `mu-plugins/rusky-preorder-notifications.php`
  - `mu-plugins/rusky-preorder-admin.php`
  - `mu-plugins/rusky-dotypos-stock-bridge.php`
  - `mu-plugins/rusky-commerce-adjustments.php`

## What still remains in the monolith

Mostly:

- compatibility shell surface
- named bootstrap/hook wiring
- store policy residue that still points at owner files

Notably, this is no longer the same kind of risk surface as before.

## Practical implication

The next cleanup pass should not try to “extract another subsystem” from the monolith.

The next cleanup pass should instead:

1. prune or classify the few remaining shell-only functions
2. decide which wrappers must stay for compatibility
3. avoid reopening already-migrated semantic blocks

## Rule for next passes

- do not mix this shell cleanup with live storefront work
- do not re-extract already-owned surfaces
- treat the file as a compatibility layer first, not as a source of business ownership
