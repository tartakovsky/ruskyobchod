# Настройка плагина Slovenská pošta ePodací hárok

**Date:** 2026-03-17 12:44
**Task:** Подключить Slovenská pošta как курьерскую службу в WooCommerce

## Goal
Настроить плагин ePodací hárok для генерации подачных листов Словенской почты из WooCommerce заказов.

## Approach
1. Найти страницу настроек плагина в WP Admin (slug: spirit-eph)
2. Активировать WebEPH API на mojezasielky.posta.sk
3. Заполнить API credentials (User ID, API Key)
4. Заполнить данные отправителя (B.A.A.B. s.r.o.)
5. Настроить параметры: способ обработки, оплаты, класс, тип отправления
6. Сохранить настройки

## Files to Modify
- Memory: обновить статус подключения курьерских служб
