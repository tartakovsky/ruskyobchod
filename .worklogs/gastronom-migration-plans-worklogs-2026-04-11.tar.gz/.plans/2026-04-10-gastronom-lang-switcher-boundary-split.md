# Gastronom Language Switcher Boundary Split

## Purpose

Separate true language-switcher responsibility from unrelated runtime, catalog, stock, and diagnostics behavior before any controlled replacement of the emergency live MU layer.

## Core language-switcher surface that should remain grouped

- language detection:
  - `gls_current_lang_code()`
  - `gls_server_lang()`
  - `gls_switcher_url()`
- brand/title localization:
  - `gls_brand_name()`
  - `gls_brand_description()`
  - `gls_translate_static_title()`
  - `gls_translate_menu_label()`
  - `gls_translate_account_checkout_phrase()`
  - `gls_normalize_public_title()`
- localized storefront text transforms:
  - `gls_localize_bilingual_text()`
  - `gls_normalize_server_rendered_html()`
  - `gls_normalize_front_page_html()`
  - `gls_normalize_storefront_chrome_html()`
  - `gls_localize_feed_link_titles()`
  - `gls_strip_inactive_language_blocks()`
- rendering shell:
  - `gls_enqueue_scripts()`
  - `gls_add_switcher()`
- guarded runtime boundary:
  - `gls_has_wp_login_cookie()`
  - `gls_is_sensitive_runtime_context()`
  - locale/gettext/template buffer hooks

## Storefront messaging that should move out

These are storefront content widgets, not language-engine behavior:

- `gls_free_shipping_banner()`
- `gls_frozen_delivery_notice()`
- `gls_footer_credit()`
- cart pickup note under `woocommerce_after_shipping_rate`

Best target:

- existing storefront/content MU surface
- likely adjacent to `rusky-storefront-messaging.php`

## Catalog sorting that should move out

These are merchandising/catalog concerns, not language switching:

- `gls_strip_diacritics()`
- `gls_parse_title()`
- `gls_update_sort_meta()`
- `gls_update_sort_meta_wc()`
- `gls_catalog_orderby()`
- `gls_default_sorting()`
- `gls_ordering_args()`
- `gls_shop_columns()`
- `gls_products_per_page()`

Best target:

- catalog/shop display surface
- likely adjacent to `rusky-product-sorting.php` or `rusky-shop-display.php`

## Weighted-product logic that should move out

These are product/stock/cart mechanics, not language switching:

- cart count override
- `gls_fix_add_to_cart_qty()`
- `woocommerce_stock_amount -> floatval`
- decimal cart update validation
- REST schema override for decimal stock quantity
- pre-save stock quantity coercion
- `_gls_weighted` product admin field/save
- quantity input args
- weighted add-to-cart validation
- weighted price suffix

Best target:

- stock/quantity domain
- likely adjacent to `rusky-stock-normalization.php`
  or a dedicated weighted-product MU surface if needed

## Dotypos diagnostics / repair surface that must move out

This is the highest-risk unrelated block currently living inside the language plugin:

- `rest_api_init` routes:
  - `gls/v1/dotypos-diag`
  - `gls/v1/dotypos-fix`
- capabilities inside this block include:
  - DB inspection
  - option deletion
  - Action Scheduler deletion
  - plugin file reads
  - plugin file writes
  - direct option updates
  - inline patching of Dotypos plugin code

This does not belong in the language plugin under any architecture.

Best target:

- isolated admin/debug tooling only
- preferably disabled entirely on production or moved to a temporary maintenance-only tool

## Immediate sequencing recommendation

1. Keep live on the emergency MU layer until the original plugin failure path is isolated.
2. Do not re-enable the original plugin with the Dotypos diagnostics block still bundled into it.
3. First local extraction candidate from this file:
   - storefront messaging block
4. Second extraction candidate:
   - catalog sorting block
5. Third extraction candidate:
   - weighted-product logic
6. Treat Dotypos diagnostic/write routes as a quarantine surface, not part of normal runtime.
