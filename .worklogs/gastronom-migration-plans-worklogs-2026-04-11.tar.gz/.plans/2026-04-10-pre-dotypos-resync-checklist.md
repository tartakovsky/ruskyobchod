# Pre-Dotypos Resync Checklist

## Goal

Return to a safe sync model in this order:

1. keep Dotypos sync disabled
2. audit current site vs cash data read-only
3. resolve clear price / VAT / stock anomalies
4. verify weighted and special stock mechanics
5. run one-way cash -> site reconciliation
6. only then re-enable site -> cash stock deduction on sale

## What is already verified

- Elementor frontend / preview stabilized
- product permalink migration backlog cleaned up
- no blind `active_plugins` or cron surgery was used
- Dotypos sync is still intentionally off

## Read-only audit findings as of 2026-04-10

Source report:

- `/Users/alexandertartakovsky/Projects/gastronom-migration/.plans/2026-04-10-dotypos-readonly-audit.json`

High-level numbers:

- site products audited: `715`
- site products with `dotypos_product_id`: `702`
- matched in Dotypos products export: `690`
- matched in `cash-all-warehouse.tsv`: `702`
- matched in revision files: `702`
- site products without Dotypos mapping: `13`
- mapped products missing in products export: `12`
- price / VAT mismatches to review: `21`
- large stock mismatches vs direct cash stock snapshot: `4`
- large stock mismatches vs revision files: `51`

## Important interpretation

### Direct cash stock comparison is the stronger stock signal

The `cash-all-warehouse.tsv` comparison is the strongest indicator for current stock drift because it uses Dotypos `productId`.

At the moment only `4` products show a coarse 2x+ stock mismatch there.

### Revision mismatch count is expected to contain noise

The `Stav skladu` / inventory comparison is useful for finding obvious outliers, but it is noisier because:

- some rows are seasonal or service items
- some rows may have sold through after revision
- some rows are compared by normalized title / EAN rather than Dotypos `productId`

So `51` mismatches there is not automatically a failure, but it is the review queue.

## Must-review groups before any resync

### 1. Direct stock mismatches vs cash

Review first:

- Pastila s Brusnicami
- Ikra Keta "Shalanda" Sklo 200 gr.
- Slanina "Mercur"
- Sleď vedro

The last two are especially important because they intersect with weight / variable-weight behavior.

### 2. Price mismatches

Review the top price divergences first, especially cases around 1.5x to 2.4x:

- several `Sušienky "Do Kávy"` / `Kravička` items
- `Sušienky Čak-Čak`
- `Zephir Kronštatské`
- some `Uvelka` cereals
- `Neva` cookie variants

These look more like stale site pricing than tax-class corruption, because the VAT values mostly still match.

### 3. Unmapped / partially mapped products

Review the `13` site products without usable Dotypos mapping and the `12` products missing from the Dotypos products export.

This bucket includes:

- delivery / service rows
- gift bags / seasonal packaging
- several likely manually added or legacy items
- a few newer products with missing SKU or missing export presence

These must not be allowed to break future sync assumptions.

### 4. Weighted and special stock mechanics

Current live data shows:

- `_gastronom_weight_preorder = yes` on `3` products
- legacy `_weighted_product = yes` count currently `0`

This must be reviewed carefully because decimal stock support and delayed Dotypos deduction are implemented in custom logic, not just in raw Woo stock fields.

## Architecture checks before re-enabling sync

### Weighted / preorder flow

Confirm that the live logic still preserves this rule:

- site order may reserve piece capacity
- Dotypos stock is updated only after actual weight confirmation for preorder-weight items

### Site -> cash direction

When site -> cash is eventually re-enabled, the scope should be narrow:

- stock deduction only
- no blind price pushes
- no tax/VAT pushes
- no catalog-wide writeback

### Cash -> site direction

Before site -> cash is re-enabled, do a controlled cash -> site reconciliation first:

- prices
- VAT classes
- stock quantities
- especially decimal / weighted items

## Recommended next sequence

1. produce a human-readable shortlist from the audit JSON
2. verify the 4 strongest cash stock mismatches one by one
3. verify the 21 price mismatches and separate legitimate manual site prices from stale values
4. inspect the 13 unmapped products and classify them:
   - service
   - seasonal
   - real catalog items needing mapping
5. audit the 3 live weight-preorder products end-to-end
6. only after that prepare one-way cash -> site sync
7. only after successful post-sync verification consider re-enabling site -> cash stock deduction
