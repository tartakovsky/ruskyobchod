# Gastronom Stock Fix Residual Surface

## Purpose

This note captures what still remains inside `plugins/gastronom-stock-fix/gastronom-stock-fix.php` after the first controlled helper migrations.

The goal is to keep the next hardening steps small and semantic instead of reopening the whole file every time.

## Already delegated

- stock normalization helpers -> `rsn_*`
- order/preorder language helpers -> `rslh_*`
- preorder helper/core calculations -> `rwp_*`
- preorder state helpers -> `rwp_*`
- preorder Dotypos bridge helpers -> `rdsb_*`
- frontend order-page language helpers -> `ropl_*`

## Residual surfaces still in the monolith

### 1. Preorder admin/product UI

Examples:

- product meta panel for `_gastronom_weight_preorder`
- product meta save logic
- admin order meta box rendering
- order screen IDs
- footer CSS/JS for order screen behavior

Why it should stay for now:

- tied to live admin hooks
- mixes rendering and Woo admin integration
- higher regression risk than helper delegation

### 2. Storefront preorder UX wiring

Examples:

- quantity input adjustments
- add-to-cart validation
- cart recalculation
- single-product preorder note
- cart notice
- payment-gateway restriction
- `/ kg` price suffix
- checkout line-item metadata capture

Why it should stay for now:

- hook-heavy runtime behavior
- visible storefront impact
- should move only after helper ownership is fully stable

### 3. Order-language page wiring

Examples:

- localized order-item name filter
- forced frontend order-language JS marker
- redirect to `?lang=...`
- output-buffer rewrite hook
- order-item actual-weight display

Current status:

- helper ownership target already exists via `ropl_*`
- hook wiring still remains in the monolith

### 4. Preorder notification / transition orchestration

Examples:

- `gastronom_send_preorder_created_emails()`
- `gastronom_send_weight_confirmation_email()`
- `gastronom_mark_weight_confirmed_order_ready()`

Why this is the next promising boundary:

- semantically coherent
- mostly order-level orchestration
- depends on already-extracted language and preorder helpers

### 5. Admin confirmation workflow

Examples:

- weight confirmation box
- AJAX/handler-adjacent behavior
- final order transition after manager confirmation

Why it should be treated carefully:

- writes order/item meta
- changes statuses
- can trigger Dotypos movement indirectly

## Recommended next cut

The next safest meaningful extraction target is:

1. preorder notification / transition helpers

Specifically:

- extract email rendering/sending helpers
- keep existing hooks in place
- delegate old `gastronom_*` entry points to new scaffold functions

After that:

2. admin confirmation workflow helpers

Only after both are stable:

3. storefront hook wiring and admin UI wiring
