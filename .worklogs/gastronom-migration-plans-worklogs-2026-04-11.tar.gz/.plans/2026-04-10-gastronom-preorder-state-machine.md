# Gastronom Preorder State Machine

## Scope

This pass documents the variable-weight preorder flow inside:

- `/Users/alexandertartakovsky/Projects/gastronom-migration/plugins/gastronom-stock-fix/gastronom-stock-fix.php`

Goal:

- isolate the preorder state machine from the rest of the junk-drawer plugin
- define a future extraction boundary for `rusky-weight-preorder.php`
- avoid mixing architecture cleanup with broader integration re-enable work

## Current conclusion

The preorder flow is a distinct two-phase model with its own state machine.

High-level model:

1. product is marked as preorder-by-weight
2. customer orders by pieces
3. Woo site stock is reserved immediately in pieces
4. order moves to `await-weight`
5. manager confirms actual weight in admin
6. order totals are recalculated
7. Dotypos stock is mutated only after confirmation
8. order moves out of `await-weight`

This is architecturally separable from:

- general decimal stock normalization
- storefront messaging
- language UI
- catalog policy

## Product-level configuration state

### Product flag and parameters

Source meta:

- `_gastronom_weight_preorder`
- `_gastronom_weight_preorder_min_kg`
- `_gastronom_weight_preorder_max_kg`
- `_gastronom_weight_preorder_note`

Admin write path:

- `woocommerce_product_options_general_product_data`
- `woocommerce_process_product_meta`

Side effect on enable:

- sets `_gls_weighted = no`
- re-applies local preorder piece stock from `_gastronom_cash_stock_kg` or fallback `_stock`

Meaning:

- this model is intended to supersede the older `_gls_weighted` behavior for these products

## Order creation state

### Line-item marking at checkout

Hook:

- `woocommerce_checkout_create_order_line_item`

For preorder products the line item gets:

- `_gastronom_weight_preorder = yes`
- `_gastronom_weight_min_kg`
- `_gastronom_weight_max_kg`
- `_gastronom_estimated_weight_kg`
- `_gastronom_price_per_kg`
- `_gastronom_weight_confirmed = no`

Meaning:

- preorder state is attached to order items, not only products
- confirmation is tracked per line item

### Order-level language marker

Hook:

- `woocommerce_checkout_create_order`

Order meta:

- `_gastronom_lang`

Meaning:

- preorder email/status messaging later depends on stored order language

## Initial post-checkout transition

### Trigger

Hook:

- `woocommerce_checkout_order_processed`

Guard:

- only runs when `gastronom_order_requires_weight_confirmation($order)` is true

### Actions

For preorder items:

- clears `_gastronom_actual_weight_kg`
- sets `_gastronom_weight_confirmed = no`
- sets `_gastronom_weight_cash_synced = no`
- clears `_gastronom_weight_cash_restored`

For order:

- deletes `_order_stock_reduced`
- sets `_gastronom_requires_weight_confirmation = yes`
- changes status to `await-weight` if needed
- reserves Woo site stock in pieces
- sends preorder-created emails

Meaning:

- Woo default stock reduction is explicitly bypassed
- this flow has its own reservation semantics

## Local reservation state

### Woo-only site reservation

Function:

- `gastronom_reserve_preorder_site_stock()`

Behavior:

- decreases local Woo `_stock` by piece quantity
- updates Woo stock status
- sets order meta `_gastronom_preorder_site_reserved = yes`

Important:

- this does not write to Dotypos

### Woo-only site restore

Function:

- `gastronom_restore_preorder_site_stock()`

Behavior:

- restores local Woo `_stock` by piece quantity
- updates Woo stock status
- sets order meta `_gastronom_preorder_site_restored = yes`

Important caveat:

- in the current repo snapshot, this function exists but was not found wired to an action in this file
- confirm whether it is called elsewhere on production before extraction

## Await-weight status state

### Order status registration

Hook:

- `init`

Registered status:

- `wc-await-weight`

Inserted into Woo status list via:

- `wc_order_statuses`

### Meaning of state

The order is:

- placed
- locally reserved
- waiting for manager confirmation of actual weight
- not yet ready for final payment flow completion
- not yet supposed to deduct stock from Dotypos

## Confirmation state

### Admin UI

Surfaces:

- custom weight confirmation box in order admin
- AJAX action `wp_ajax_gastronom_confirm_weight`

Per preorder item the manager can submit:

- actual weight in kg

### Confirmation transition

On successful admin confirmation:

- recalculates line subtotal and total using actual weight and price per kg
- writes `_gastronom_actual_weight_kg`
- writes `_gastronom_weight_confirmed = yes`
- recalculates taxes and order totals
- adds order note
- calls `gastronom_sync_confirmed_preorder_items_to_dotypos($order)`
- calls `gastronom_mark_weight_confirmed_order_ready($order)`

Meaning:

- confirmation is the key state transition where the order stops being an estimate and becomes a cash-affecting order

## Ready-after-confirmation transition

### Function

- `gastronom_mark_weight_confirmed_order_ready()`

Behavior:

- normalizes preorder item state
- exits early if any preorder item still requires confirmation
- sets `_gastronom_requires_weight_confirmation = no`
- if order status is `await-weight`, moves it to:
  - `on-hold` for COD
  - `pending` for online payment
- sends weight-confirmation email

Meaning:

- the order leaves the preorder waiting state only after all preorder items are confirmed

## Cash sync state

This is documented separately in:

- `/Users/alexandertartakovsky/Projects/gastronom-migration/.plans/2026-04-10-gastronom-stock-fix-dotypos-write-surface.md`

Short version:

- Dotypos write happens only after confirmation
- restore happens only on cancellation/refund for already-synced preorder items

## State inventory

### Product state

- preorder disabled
- preorder enabled

### Order-item state

- preorder item not present
- preorder item present, unconfirmed
- preorder item confirmed
- preorder item cash synced
- preorder item cash restored

### Order state

- ordinary order
- preorder order requiring confirmation
- preorder order in `await-weight`
- preorder order confirmed and moved to `pending` or `on-hold`

## Extraction boundary recommendation

A future `rusky-weight-preorder.php` should own:

- product preorder fields
- quantity and validation rules
- line-item preorder metadata
- reservation and restore of Woo piece stock
- `await-weight` status registration and transitions
- admin confirmation UI and AJAX
- confirmation emails

It should not own:

- vendor Dotypos hook suppression
- generic decimal stock normalization
- catalog policy
- storefront merchandising
- unrelated language helpers except the smallest localized-order messaging required for preorder emails

## Open ambiguities to resolve before extraction

1. `gastronom_restore_preorder_site_stock()` exists, but its active hook wiring is not visible in this file snapshot.
2. The preorder flow still depends on shared helper functions for language localization inside the same junk-drawer file.
3. The older `_gls_weighted` model still exists elsewhere and must stay explicitly non-overlapping.

## Next safe hardening step

Inventory which language/order-localization helpers are truly required by the preorder flow versus which ones are generic language-layer leakage.

That will allow the preorder extraction to depend on a narrow compatibility helper surface instead of dragging the language layer with it.
