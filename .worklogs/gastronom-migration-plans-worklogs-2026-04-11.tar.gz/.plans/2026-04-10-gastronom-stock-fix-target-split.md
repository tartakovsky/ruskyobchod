# Gastronom Stock Fix Target Split

## Purpose

This document turns the previous inventories into a concrete split design for:

- `/Users/alexandertartakovsky/Projects/gastronom-migration/plugins/gastronom-stock-fix/gastronom-stock-fix.php`

The goal is not to rewrite the plugin in one pass.

The goal is to define safe extraction slices that reduce fragility while keeping integration re-enable deferred.

## Current conclusion

`gastronom-stock-fix.php` should not be treated as one plugin anymore.

The first target split should be:

1. `rusky-weight-preorder.php`
2. `rusky-dotypos-stock-bridge.php`
3. `rusky-stock-normalization.php`
4. residual `gastronom-stock-fix.php` cleanup only after the first three surfaces exist

## Target surfaces

### 1. `mu-plugins/rusky-weight-preorder.php`

This should own the preorder state machine.

Move here:

- preorder product flags and admin fields
- preorder min/max/note helpers
- piece-capacity math
- checkout line-item metadata
- `await-weight` status registration
- Woo-only local reservation
- Woo-only local restore
- confirmation-required checks
- manager confirmation AJAX
- admin confirmation UI
- order recalculation after actual weight confirmation
- transition from `await-weight` to `pending` / `on-hold`
- preorder-created emails
- weight-confirmation email
- preorder-specific storefront notices and item metadata

Dependencies allowed:

- narrow preorder language helper surface only
- no direct general site -> cash sync re-enable

Dependencies not allowed:

- runtime plugin overrides
- generic catalog policy
- vendor hook surgery outside preorder scope

### 2. `mu-plugins/rusky-dotypos-stock-bridge.php`

This should own the narrow Dotypos bridge behavior.

Move here:

- vendor `handle_product_updated` suppression
- delayed preorder deduction to Dotypos
- delayed preorder restore to Dotypos
- immediate post-write Woo refresh from Dotypos raw stock
- any verified live hook wiring for:
  - `gastronom_apply_dotypos_stock_to_wc_product()`
  - `gastronom_resolve_dotypos_order_sync_quantity()`

Hard constraints:

- no broad site -> cash stock sync enablement
- no hidden vendor patching
- one file owns the Dotypos bridge

Open caveat:

- two helper functions appear intended for bridge integration but are not referenced in the repo snapshot
- production hook wiring must be confirmed before extracting them as live behavior

### 3. `mu-plugins/rusky-stock-normalization.php`

This should own generic Woo stock correctness, not preorder business flow.

Move here:

- decimal stock filter setup
- REST schema adjustment for decimal stock
- `_stock` to `_stock_status` reconciliation
- `_manage_stock` / `_backorders` alignment for generic stock normalization
- stock-related one-time repair logic if it still needs to exist

Do not move here:

- preorder reservation semantics
- Dotypos writes
- storefront merchandising

### 4. Residual `gastronom-stock-fix.php`

After the first three surfaces exist, this file should shrink toward zero or near-zero ownership.

Likely residuals to classify before deletion:

- low stock email suppression / store policy
- COD fee / gateway description tweaks if still needed
- any leftover order-display fragments
- any leftover language leakage not yet moved cleanly

## Shared helper decision

The preorder extraction needs a narrow shared helper surface for order language.

Preferred target:

- `mu-plugins/rusky-order-language-helpers.php`

This helper should contain only:

- current/order language lookup
- RU/SK short text helpers
- order-locale wrapper
- bilingual title split/localize
- localized shipping/payment label map

This avoids dragging generic language-layer behavior into preorder.

## Extraction order

### Step 1

Create `rusky-order-language-helpers.php` locally.

Reason:

- it reduces coupling before moving preorder email/admin/order rendering logic

### Step 2

Create `rusky-weight-preorder.php` locally by moving the preorder state machine with helper imports only.

Reason:

- this is the biggest semantic block and already has a clean lifecycle

### Step 3

Create `rusky-dotypos-stock-bridge.php` locally.

Reason:

- this narrows cash mutation ownership to one file

### Step 4

Create `rusky-stock-normalization.php` locally.

Reason:

- generic stock correctness should stop living next to preorder/order/email code

### Step 5

Remove moved blocks from `gastronom-stock-fix.php` one slice at a time and regenerate inventories/worklogs after each cut.

## Safety rules for implementation

- do not combine extraction with sync re-enable
- do not deploy all three slices at once
- move one semantic block only
- verify ownership after each cut
- keep `gastronom-stock-fix.php` readable during the transition, not half-broken

## First implementation candidate

The first real code extraction should be:

- `rusky-order-language-helpers.php`

Why this first:

- smallest new surface
- unlocks preorder extraction cleanly
- low risk compared with moving stateful preorder logic immediately

## Immediate next step

Design the exact function set and file skeleton for:

- `mu-plugins/rusky-order-language-helpers.php`

That is the next hardening step that turns documentation into an actual extraction-ready boundary.
