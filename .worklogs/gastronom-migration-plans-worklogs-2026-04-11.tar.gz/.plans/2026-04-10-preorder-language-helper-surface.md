# Preorder Language Helper Surface

## Purpose

This pass narrows the language/order-localization dependency surface that the preorder flow actually needs.

Source reviewed:

- `/Users/alexandertartakovsky/Projects/gastronom-migration/plugins/gastronom-stock-fix/gastronom-stock-fix.php`

Goal:

- prepare the future preorder extraction without dragging generic language behavior into it

## Current conclusion

The preorder flow does not need the whole language layer.

It needs a small helper surface for:

- current storefront language at checkout
- persisted order language
- short RU/SK inline message selection
- temporary locale switch for emails
- bilingual title splitting/localization for order content
- translation of a small set of shipping/payment labels

## Helpers that look genuinely required by preorder

### Order language capture / lookup

- `gastronom_current_lang()`
- `gastronom_order_lang()`

Why needed:

- checkout stores `_gastronom_lang`
- later preorder emails and status notes depend on stable order language

### Minimal RU/SK message selection

- `gastronom_tt()`
- `gastronom_t()`

Why needed:

- preorder validation notices
- preorder frontend labels
- order notes after weight confirmation
- status note after leaving `await-weight`

### Email locale wrapper

- `gastronom_locale_for_order()`
- `gastronom_with_order_locale()`

Why needed:

- preorder-created emails
- weight-confirmation email

### Bilingual product/order label localization

- `gastronom_split_bilingual_title()`
- `gastronom_localize_title()`
- `gastronom_localize_order_label()`

Why needed:

- line-item names inside preorder email
- shipping/payment labels inside preorder email
- some order-display surfaces

## Helpers that should not block preorder extraction

These are in the same file today, but they are not the reason preorder must stay inside the junk drawer:

- public language switcher behavior
- generic storefront title rewriting
- broad runtime HTML normalization
- catalog-wide language presentation

Those belong to the language layer, not to preorder.

## Recommended extraction boundary

Future `rusky-weight-preorder.php` should depend on one of these:

### Option A

A tiny shared helper file, for example:

- `mu-plugins/rusky-order-language-helpers.php`

Containing only:

- current/order language lookup
- RU/SK short text helpers
- order-locale wrapper
- bilingual title split/localize
- shipping/payment label map

### Option B

Keep a minimal local copy inside preorder extraction if shared ownership becomes more confusing than duplication.

Current preference:

- Option A is cleaner if the same helpers are also needed by other order/email surfaces

## Immediate practical rule

When extracting preorder, do not move every language helper from `gastronom-stock-fix`.

Move only the helper set that preorder demonstrably calls:

- `gastronom_current_lang`
- `gastronom_order_lang`
- `gastronom_tt`
- `gastronom_t`
- `gastronom_locale_for_order`
- `gastronom_with_order_locale`
- `gastronom_split_bilingual_title`
- `gastronom_localize_title`
- `gastronom_localize_order_label`

## Next safe hardening step

Design the target split for `gastronom-stock-fix` into these first-class surfaces:

1. preorder state machine
2. Dotypos stock bridge
3. decimal stock normalization
4. residual order/store policy helpers
