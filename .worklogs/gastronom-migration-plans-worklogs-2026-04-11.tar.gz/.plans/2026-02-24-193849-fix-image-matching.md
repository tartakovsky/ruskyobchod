# Fix image matching script — multi-strategy name matching

**Date:** 2026-02-24 19:38
**Task:** Rewrite match_images.py to use multiple matching strategies instead of slug-only matching

## Goal
Match as many old site products (450) to new site products (630) as possible, so we can transfer images.

## Context
- Old site uses `.` or `/` as Slovak/Russian separator, order varies (sometimes Russian first)
- New site consistently uses `/` as separator (Slovak/Russian order)
- Slug matching only finds 4 products because slugs are completely different between sites
- Exact name match finds ~6 products
- Names are similar but differ in formatting, punctuation, weight notation, etc.

## Approach

### Matching strategies (in priority order)
1. **Exact slug match** — keeps the 4 that already work
2. **Exact name match** — after HTML entity decoding
3. **Normalized full name match** — lowercase, strip, decode HTML entities, normalize whitespace
4. **Russian part fuzzy match** — extract Russian text (after `/` or `.` separator), normalize, use SequenceMatcher >= 0.85
5. **Slovak part fuzzy match** — extract Slovak text (before separator), normalize, SequenceMatcher >= 0.85
6. **Full name fuzzy match** — SequenceMatcher on normalized full name >= 0.75

### Name extraction logic
- Split by `/` first (new site standard)
- If no `/`, split by `.` and detect which part is Cyrillic vs Latin
- Handle reversed order (Russian first in some old products)

### Media matching (unchanged)
- Once product matched, use existing filename/stem matching for media

## Risks & Edge Cases
- False positives with fuzzy matching on short names
- Multiple old products matching same new product (e.g. different sizes)
- Need to ensure each old product matches at most one new product

## Files to Modify
- `match_images.py` — rewrite matching logic with multi-strategy approach
