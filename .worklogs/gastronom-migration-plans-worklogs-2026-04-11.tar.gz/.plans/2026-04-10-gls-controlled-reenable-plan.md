# GLS Controlled Re-enable Plan

## Goal

Replace the emergency storefront continuity layer with the cleaned original language plugin only through a reversible, tightly verified sequence.

This plan is intentionally operationally conservative and follows the handoff rule set:

- smallest safe surface first
- one semantic block at a time
- immediate verification after each live step
- freeze live if the storefront is already acceptable

## Preconditions

- live storefront remains on the current emergency MU arrangement
- no new cosmetic changes are made on live before the experiment
- local cleaned baseline exists:
  - `/Users/alexandertartakovsky/Projects/gastronom-migration/gastronom-lang-switcher/gastronom-lang-switcher.php`
- local cleaned baseline is diff-clean versus:
  - `/Users/alexandertartakovsky/Projects/gastronom-migration/gastronom-lang-switcher.live-current.php`
- extracted owners remain local and separate:
  - `mu-plugins/rusky-storefront-messaging.php`
  - `mu-plugins/rusky-shop-display.php`
  - `mu-plugins/rusky-commerce-adjustments.php`
  - `mu-plugins/rusky-product-sorting.php`
  - `mu-plugins/rusky-dotypos-maintenance.php`

## Live experiment sequence

1. Snapshot the currently deployed live files that participate in language/runtime behavior.
   Minimum set:
   - live `gastronom-lang-switcher`
   - live `rusky-disable-far.php`
   - live `rusky-language-switcher-lite.php`

2. Upload the cleaned `gastronom-lang-switcher.php` to a temporary path only.
   Do not activate it yet.

3. Lint the uploaded temporary file on the server.

4. Prepare a single reversible switch step.
   Intended switch:
   - stop filtering `gastronom-lang-switcher` out of active plugins
   - disable the emergency `rusky-language-switcher-lite.php`
   - keep every other extracted owner unchanged

5. Execute the switch once.
   No follow-up “polish” changes in the same window.

6. Verify immediately.
   Required checks:
   - `curl -ksI https://ruskyobchod.sk/`
   - `curl -ksI https://ruskyobchod.sk/wp-login.php`
   - `curl` RU homepage snippet
   - `curl` SK homepage snippet
   - one isolated Chrome visual check on RU
   - one isolated Chrome visual check on SK

7. If any regression appears, revert immediately.
   Revert means:
   - reapply live plugin bypass
   - re-enable emergency lite MU
   - stop

## Success criteria

- homepage remains `200`
- `wp-login.php` remains `200`
- no duplicated bilingual front-page blocks
- switcher is visible and active state is clear
- RU and SK top navigation are readable
- no site-wide runtime instability appears during the switch

## Explicit non-goals for the same window

- do not fix checkout/cart translation polish in the same experiment
- do not refactor `gastronom-stock-fix`
- do not merge new storefront cosmetics
- do not expand emergency MU behavior
