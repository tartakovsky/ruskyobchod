# Integration Readiness Checklist

Date: 2026-04-11 10:38:30 +0200

## Purpose

This is the short end-state checklist for the current hardening phase.

It is intentionally not a rebuild plan.

It answers one question:

- what still must be true before the codebase is in a sane enough state for the next integration step

## Already true

- storefront RU critical path was stabilized on live and verified in browser for the latest reproduced defects
- `gastronom-stock-fix.php` is now primarily a compatibility/fallback shell
- semantic ownership has been split across dedicated owner files in `mu-plugins/`
- owner map exists
- wrapper retention classification exists
- Dotypos shim-risk wrappers were explicitly audited and kept
- handoff and worklogs are now sufficient to continue without rediscovering the same boundaries

## Still required before saying “ready”

1. No new live storefront regressions appear in the selling path:
   - homepage
   - category
   - product
   - cart
   - checkout

2. The current shell/fallback model stays stable:
   - no duplicate wrapper owners
   - no new anonymous hook blocks reintroduced into the monolith

3. The two Dotypos shim wrappers remain explicitly unresolved but contained:
   - `gastronom_apply_dotypos_stock_to_wc_product()`
   - `gastronom_resolve_dotypos_order_sync_quantity()`

4. Future work stops treating `gastronom-stock-fix.php` as an implementation home:
   - only shell cleanup
   - only verified shim retention or deletion

5. Any next live deploy follows the existing operating contract:
   - one changed file
   - immediate browser verification on the broken path
   - handoff/worklog updated right after

## Current status after latest audits

- sellable storefront freeze-check exists and the latest RU live path remains usable
- wrapper overlap audit passed
- monolith wrapper coverage audit passed with `0` uncovered wrappers
- refreshed runtime inventory now reflects the full current `rusky-*` owner set
- the only explicitly unresolved technical boundary is still the two Dotypos shim wrappers pending vendor/live runtime proof

## Practical meaning of “ready”

For this phase, “ready” does not mean the site is beautifully rebuilt.

It means:

- the site is sellable
- the live language/storefront path is not being destabilized by ongoing hardening
- the stock/preorder/Dotypos code is separated enough that the next integration move can be intentional instead of exploratory

## Not included in this readiness claim

- full GLS root-cause rebuild
- full Dotypos reintegration redesign
- deletion of every compatibility wrapper
- complete repo/live parity proof
