# Update _gls_weighted meta for WooCommerce products

**Date:** 2026-03-15 17:21
**Task:** Reset all _gls_weighted=yes to no, then set specific 66 products to yes

## Goal
Only the specified ~66 products should have `_gls_weighted=yes`. All others should be `no`.

## Approach

### Step-by-step plan
1. Write Python script that:
   - Fetches all products (paginated, 100/page)
   - Finds products with _gls_weighted=yes, batch-updates them to no
   - Matches product names against the 66 specified substrings
   - Batch-updates matched products to _gls_weighted=yes
2. Run the script
3. Commit

## Files to Modify
- `update_gls_weighted.py` — new script
