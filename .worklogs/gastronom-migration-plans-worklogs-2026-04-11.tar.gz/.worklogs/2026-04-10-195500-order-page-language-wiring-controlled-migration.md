# Order Page Language Wiring Controlled Migration

## Scope

Local architecture hardening only.

No live deploy.
No storefront runtime change today.

## Goal

Reduce residual frontend order-page language wiring inside:

- `/Users/alexandertartakovsky/Projects/gastronom-migration/plugins/gastronom-stock-fix/gastronom-stock-fix.php`

by widening the already existing owner file:

- `/Users/alexandertartakovsky/Projects/gastronom-migration/mu-plugins/rusky-order-page-language.php`

## What moved

New helper ownership added to `rusky-order-page-language.php`:

- `ropl_localize_order_item_name()`
- `ropl_render_forced_order_lang_marker()`
- `ropl_maybe_redirect_context_order_lang()`
- `ropl_start_order_page_buffer()`

Existing ownership already there:

- `ropl_context_order()`
- `ropl_normalize_order_page_html()`

## What changed in the monolith

`gastronom-stock-fix.php` now keeps hook registration but delegates these order-page runtime concerns to `ropl_*` when available for:

- `woocommerce_order_item_name`
- `wp_head`
- early `template_redirect` language redirect
- later `template_redirect` output-buffer startup

## Result

Frontend order-page language ownership is now more coherent:

- context order resolution
- page HTML normalization
- localized order item names
- forced frontend language marker
- redirect to canonical `?lang=...`
- output buffer startup

are grouped under one extraction surface.

This reduces another real residual block in the monolith without introducing new live risk.
