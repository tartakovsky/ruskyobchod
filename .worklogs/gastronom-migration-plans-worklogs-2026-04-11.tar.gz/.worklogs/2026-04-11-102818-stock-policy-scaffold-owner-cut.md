# Stock Policy Scaffold Owner Cut

Date: 2026-04-11 10:28:18 +0200

## Scope

Local-only architecture hardening.

No live deploy.

## What changed

- added new owner scaffold:
  - `mu-plugins/rusky-stock-policy.php`
- moved the last shared stock-policy/bootstrap helper surface into `rsp_*` functions there:
  - decimal stock amount setup
  - stock notification option disable
  - stock email action disable
  - Dotypos product-update hook detach
  - REST decimal stock endpoint adjustment
  - stock reconciliation triggers
  - one-time stock repair run
- exposed guarded compatibility wrappers for the matching `gastronom_*` surface so the monolith can stay fallback-only for this slice too

## Result

- the remaining monolith residue is now clearly split into owner files even for the policy/bootstrap layer
- `gastronom-stock-fix.php` is very close to being only a compatibility/fallback shell
