## Context

Continuing architecture hardening while the parallel XLSX task for integration preparation was being simplified against the fresh cash export.

This pass focused on the next promised preorder-extraction prerequisite:

- identify the minimal language helper surface actually required by preorder

## What was done

Reviewed the helper functions inside:

- `/Users/alexandertartakovsky/Projects/gastronom-migration/plugins/gastronom-stock-fix/gastronom-stock-fix.php`

Mapped them against actual preorder uses:

- checkout language capture
- preorder notices
- preorder-created emails
- weight-confirmation email
- order notes / status transitions

## Findings

- Preorder does not need the whole language layer.
- It needs a narrow helper surface only:
  - current/order language lookup
  - RU/SK short text helpers
  - temporary locale switch for emails
  - bilingual title localization
  - small shipping/payment label map

## Artifact

- Added:
  - `/Users/alexandertartakovsky/Projects/gastronom-migration/.plans/2026-04-10-preorder-language-helper-surface.md`

## Next step

Use the three architecture inventory artifacts together to define the first real extraction boundary from `gastronom-stock-fix`:

- preorder state machine
- Dotypos write bridge
- preorder language helper surface
