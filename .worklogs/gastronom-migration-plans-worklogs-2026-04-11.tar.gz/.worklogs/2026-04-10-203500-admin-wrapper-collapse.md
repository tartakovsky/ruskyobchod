# Admin Wrapper Collapse

## Scope

Local architecture hardening only.

No live deploy.

## Goal

Remove another duplicated admin fallback body from:

- `/Users/alexandertartakovsky/Projects/gastronom-migration/plugins/gastronom-stock-fix/gastronom-stock-fix.php`

where the admin owner file is already in place.

## Change

Collapsed these monolith functions to thin wrappers:

- `gastronom_render_weight_confirmation_box()`
- `gastronom_order_screen_ids()`

They now rely on:

- `/Users/alexandertartakovsky/Projects/gastronom-migration/mu-plugins/rusky-preorder-admin.php`

and otherwise return safe neutral outcomes:

- render nothing extra
- return an empty screen-id list

## Result

The preorder admin block now has less duplicated rendering logic inside the monolith and clearer ownership in `rusky-preorder-admin.php`.
