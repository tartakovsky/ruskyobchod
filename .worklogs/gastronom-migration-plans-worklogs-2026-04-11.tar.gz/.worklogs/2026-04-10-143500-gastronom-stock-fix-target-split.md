## Context

Continuing the main architecture-hardening track after completing the supporting XLSX cleanup on the parallel integration-preparation task.

This pass used the existing inventories to produce the first concrete split design for `gastronom-stock-fix.php`.

## What was done

Combined these inventory artifacts:

- Dotypos write surface
- preorder state machine
- preorder language helper surface
- runtime ownership map

Produced a target split design for the junk-drawer plugin.

## Result

The recommended split is now explicit:

1. `rusky-weight-preorder.php`
2. `rusky-dotypos-stock-bridge.php`
3. `rusky-stock-normalization.php`
4. residual cleanup in `gastronom-stock-fix.php`

The first actual implementation candidate is:

- `rusky-order-language-helpers.php`

Reason:

- smallest useful extraction
- lowers coupling before moving preorder logic
- keeps sync re-enable out of scope

## Artifact

- Added:
  - `/Users/alexandertartakovsky/Projects/gastronom-migration/.plans/2026-04-10-gastronom-stock-fix-target-split.md`

## Next step

Design the exact skeleton and function ownership for:

- `mu-plugins/rusky-order-language-helpers.php`
