# Preorder Storefront Wiring Controlled Migration

## Scope

Local architecture hardening only.

No live deploy.
No storefront runtime activation change.

## Goal

Stop keeping preorder storefront/runtime helper bodies inside:

- `/Users/alexandertartakovsky/Projects/gastronom-migration/plugins/gastronom-stock-fix/gastronom-stock-fix.php`

by giving them a dedicated owner file.

## New owner surface

Added:

- `/Users/alexandertartakovsky/Projects/gastronom-migration/mu-plugins/rusky-preorder-storefront.php`

Owned helper surface there now includes:

- `rpsf_quantity_input_args()`
- `rpsf_add_to_cart_quantity()`
- `rpsf_add_to_cart_validation()`
- `rpsf_before_calculate_totals()`
- `rpsf_get_item_data()`
- `rpsf_render_single_product_note()`
- `rpsf_render_cart_notice()`
- `rpsf_available_payment_gateways()`
- `rpsf_price_html()`
- `rpsf_checkout_create_order()`
- `rpsf_checkout_create_order_line_item()`

## Monolith change

`gastronom-stock-fix.php` still keeps the live Woo hook registration for now, but those hook bodies now delegate to `rpsf_*` when available for:

- quantity input args
- add-to-cart quantity normalization
- add-to-cart validation
- cart total recalculation
- cart item data rendering
- single-product preorder note
- cart notice
- available payment gateways
- `/ kg` price suffix
- checkout order language capture
- checkout line-item preorder metadata capture

## Result

The preorder storefront UX/runtime block is no longer ownerless.

Admin/product-meta, order-page language, and storefront preorder behavior now each have separate local extraction surfaces instead of continuing to accrete in the monolith.
