# Удалены дубликаты, исправлены категории и SKU

**Date:** 2026-03-15 23:08
**Scope:** WooCommerce REST API operations, fix_duplicates_categories.py

## Summary
Cleaned up WooCommerce catalog: deleted 18 duplicate products, moved 15 products from "Алкогольные напитки" to "Орехи семечки сухофрукты", fixed 38 SKUs with trailing/leading commas. Also fixed 4 products where multiple comma-separated barcodes got concatenated — kept only the first barcode.

## Context & Problem
After Dotypos sync, catalog had duplicate products (higher IDs from import), products miscategorized under "Алкогольные напитки" that should be in "Орехи семечки сухофрукты", and SKUs with stray commas.

## Decisions Made

### Multiple barcodes in SKU
- **Chose:** Keep only the first barcode for products with multiple comma-separated barcodes
- **Why:** SKU field should have one identifier; the concatenated barcodes would break barcode scanning

## Open Questions / Future Considerations
- 4 products had genuinely multiple barcodes — only the first was kept. If the other barcodes are needed, they'd need a custom field.
