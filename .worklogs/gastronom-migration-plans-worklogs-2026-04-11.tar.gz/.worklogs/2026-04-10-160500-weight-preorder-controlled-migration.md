## Context

Continuing the same controlled-migration pattern after moving language helpers toward `rslh_*`.

The next lowest-risk boundary was the variable-weight preorder helper/core surface.

## What changed

Inside `plugins/gastronom-stock-fix/gastronom-stock-fix.php`, these entry points now delegate to `rwp_*` when available:

- `gastronom_weight_preorder_min_kg()`
- `gastronom_weight_preorder_max_kg()`
- `gastronom_weight_preorder_avg_kg()`
- `gastronom_weight_preorder_price_per_kg()`
- `gastronom_weight_preorder_reserved_qty()`
- `gastronom_weight_preorder_piece_capacity()`
- `gastronom_apply_preorder_piece_stock()`
- `gastronom_preorder_item_is_confirmed()`
- `gastronom_order_requires_weight_confirmation()`

Fallback implementations remain in-place.

## Why this is safe

- existing call sites were not rewritten
- no hook wiring changed
- runtime still enters through the old `gastronom_*` function names
- if the scaffold MU file is missing, behavior still falls back to the old implementation

## Result

The preorder helper/core ownership has now started shifting out of the monolithic plugin file, while the live runtime surface remains stable.

## Next step

Continue with the Dotypos preorder bridge surface:

- move `gastronom_apply_dotypos_stock_to_wc_product()`
- move `gastronom_resolve_dotypos_order_sync_quantity()`
- then evaluate confirmed preorder stock sync/restore helpers for the same delegation pattern
