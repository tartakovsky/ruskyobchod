# Fuzzy matching unmapped products to images

**Date:** 2026-02-24 23:28
**Scope:** gastronom-migration/match_products_images.py, products_images_mapped.csv, products_unmapped.csv, images_unmapped.csv

## Summary
Created and ran a fuzzy keyword matching script to pair 306 unmapped products with 408 unmapped images. Result: 42 matches found, leaving 260 unmapped products and 362 unmapped images.

## Context & Problem
After previous direct matching rounds (by SKU, exact name), 306 products still lacked images. Many images have filenames in Russian transliteration while product names are in Slovak. Fuzzy keyword matching was needed.

## Decisions Made

### Require at least one "specific" keyword match
- **Chose:** Filter out matches based only on generic category words (konfety, pechene, krupa, etc.)
- **Why:** Without this, "Krupa Ris" would match any image with "Krupa" in the name

### Score = 60% image coverage + 40% product coverage
- **Chose:** Weight image keyword coverage higher
- **Why:** Images have fewer keywords, so matching most of them means a more specific match

### Minimum threshold score 0.35 with 2+ keyword matches
- **Chose:** Relatively low threshold since specific-match filter handles quality
- **Why:** Some valid matches have low scores because products have many keywords (bilingual names)

## Open Questions / Future Considerations
- Some matches are wrong (e.g. Doshirak chicken matched to beef image) -- need manual review
- ~260 products remain unmapped -- many images have meaningless filenames (hashes, UUIDs)
- Could try matching by SKU/barcode if images have that info somewhere

## Next Steps
1. Manual review of the 42 matches for quality
2. Apply confirmed matches via WooCommerce API
3. For remaining 260 products, may need manual image assignment or different approach
