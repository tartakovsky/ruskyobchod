# Исправление названий и финализация сортировки

**Date:** 2026-03-17 16:53
**Scope:** gastronom-stock-fix.php (v1.1→v1.9), gls-script.js, sort_products.py, 33 товара WC

## Summary
33 товара с нестандартными названиями приведены к формату «Slovak / Russian». Сортировка по алфавиту реализована как одна опция в dropdown, автоматически определяющая язык через localStorage. Slug категории «Орехи» исправлен.

## Context & Problem
- 33 товара имели нестандартные названия: без разделителя, с `/` без пробелов, с `. ` разделителем, или на одном языке
- Сортировка: cookie-подход не работал, WooCommerce перезаписывал pre_get_posts, plugin editor не сохранял изменения

## Decisions Made

### Сортировка: одна опция + JS перехват
- **Chose:** PHP регистрирует опцию `alphabetical` = "A-Z". JS на клиенте: (1) переименовывает в "По алфавиту"/"Podľa abecedy" по языку из localStorage, (2) подменяет value на `alphabetical_ru`/`alphabetical_sk`, (3) при загрузке с ?orderby=alphabetical_* ставит опцию как selected
- **Why:** Cookie ненадёжный (не ставился/не читался PHP). Два пункта в dropdown — путает пользователя. JS + localStorage — единственный надёжный источник языка.

### Деплой через ZIP
- **Chose:** Деактивировать → удалить → загрузить ZIP → активировать (Python requests)
- **Why:** Plugin editor (POST plugin-editor.php) сохранял изменения нестабильно — nonce поле называлось `nonce` а не `_wpnonce`, и даже с правильным nonce иногда не применялось

### Исправление названий
- **Chose:** Массовое обновление через WC REST API
- **Why:** 33 товара с нестандартным форматом ломали переключатель языков

## Итого версий плагина за сессию
- v1.1: COD fee (начало сессии)
- v1.2: + pre_get_posts (forced sorting) — не работало
- v1.3: + woocommerce_catalog_orderby dropdown — plugin editor не сохранял
- v1.4-v1.6: фиксы dropdown text и ordering args
- v1.7: два пункта A-Z / А-Я
- v1.8: одна опция + JS перехват
- v1.9: + JS selected fix при перезагрузке

## Open Questions
- Новые товары из Dotypos не получат мета-поля автоматически — нужен повторный запуск sort_products.py
- 2 товара с ID 10127 и 10108 оба "Káva espresso" — возможный дубликат
