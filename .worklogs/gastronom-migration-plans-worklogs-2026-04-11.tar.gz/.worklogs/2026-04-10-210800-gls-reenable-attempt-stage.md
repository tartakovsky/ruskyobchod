## Context

A controlled live re-enable experiment was started from the cleaned local baseline, following the handoff sequence:

1. snapshot live files
2. upload cleaned plugin to temp path
3. remote `php -l`
4. one reversible runtime switch
5. immediate verification only

## Completed steps

- Live snapshots saved locally:
  - `_snapshots/2026-04-10-live-pre-reenable-rusky-disable-far.php`
  - `_snapshots/2026-04-10-live-pre-reenable-rusky-language-switcher-lite.php`
  - `_snapshots/2026-04-10-live-pre-reenable-gastronom-lang-switcher.php`
- Cleaned `gastronom-lang-switcher.php` uploaded to temp path on server
- Remote `php -l` passed for temp file
- Missing owner file deployed before switch:
  - `mu-plugins/rusky-dotypos-maintenance.php`
- Cleaned `gastronom-lang-switcher.php` deployed to the live plugin path
- Runtime switch executed:
  - `gastronom-lang-switcher` unblocked in live `rusky-disable-far.php`
  - emergency `rusky-language-switcher-lite.php` renamed out of the active MU set

## Immediate verification result

- `https://ruskyobchod.sk/` returned `200`
- `https://ruskyobchod.sk/wp-login.php` returned `200`
- isolated RU visual check looked acceptable
- isolated SK visual check looked acceptable

## Current open issue after re-enable

The site stayed up, but one old front-page presentation issue appears to have resurfaced in raw HTML verification:

- duplicate skip-link structure
- front-page breadcrumb block
- front-page `vw-page-title`

A targeted local patch was prepared and deployed to restore that cleanup inside `gls_normalize_front_page_html()`, but the public curl output has not yet confirmed the effect.

## Rule checkpoint

- no broad rollback was done
- no new feature work was mixed in
- current state has been saved before proceeding further
