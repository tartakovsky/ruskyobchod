## Context

After the live `503` recovery, the next task was to isolate the likely failure path inside `gastronom-lang-switcher` without re-enabling it on production.

## What was compared

- `/Users/alexandertartakovsky/Projects/gastronom-migration/gastronom-lang-switcher.live-current.php`
- `/Users/alexandertartakovsky/Projects/gastronom-migration/gastronom-lang-switcher/gastronom-lang-switcher.php`

## Strong failure candidate

The local/plugin working copy removed the broader sensitive-runtime guard that existed in `live-current`.

In `live-current`:

- `gls_has_wp_login_cookie()` existed
- `gls_is_sensitive_runtime_context()` treated these as sensitive:
  - admin non-AJAX
  - AJAX
  - REST
  - XML-RPC
  - Elementor preview
  - requests carrying `wordpress_*` auth cookies

That broader guard was then used to short-circuit:

- `locale`
- `determine_locale`
- `gettext`
- `template_redirect` output buffering
- WooPayments locale/script rewrites

In the newer local/plugin file:

- `gls_has_wp_login_cookie()` is gone
- `gls_is_sensitive_runtime_context()` was replaced by narrower `gls_is_sensitive_runtime_request()`
- the narrower guard no longer treats auth-cookie requests as sensitive
- several locale / script rewrite surfaces now run on a wider request set
- `template_redirect` now skips logged-in users explicitly, but the locale/gettext/script surfaces were still widened before that point

## Why this is a serious candidate

The outage scope was site-wide and affected both:

- homepage
- `wp-login.php`

That pattern is consistent with a plugin that widened locale/gettext/runtime mutations beyond ordinary storefront requests, rather than a narrow front-page-only rendering bug.

## Additional risk found

This plugin is architecturally oversized for a language switcher. It currently mixes:

- locale overrides
- gettext rewriting
- output buffering + DOM parsing
- WooPayments/Stripe locale mutation
- catalog sorting logic
- weighted-product quantity logic
- REST endpoints with plugin file read/write capability

This confirms the user concern that emergency storefront continuity must not turn into a new permanent patch layer.

## Safe next step

Do not re-enable the plugin on live yet.

Next safe analysis step:

- reconstruct the minimal protective boundary from `live-current`
- isolate which of these widened surfaces is necessary vs dangerous:
  - locale/determine_locale
  - gettext
  - template_redirect buffer
  - WooPayments script mutation
