# Preorder Admin UI Controlled Migration

## Scope

Local architecture hardening only.

No live deploy.
No runtime owner change.
No storefront change.

## Goal

Reduce the residual admin confirmation workflow inside:

- `/Users/alexandertartakovsky/Projects/gastronom-migration/plugins/gastronom-stock-fix/gastronom-stock-fix.php`

by moving more of its admin UI helper ownership into:

- `/Users/alexandertartakovsky/Projects/gastronom-migration/mu-plugins/rusky-preorder-admin.php`

## What moved

New helper ownership added to `rusky-preorder-admin.php`:

- `rpa_hidden_meta_box_ids()`
- `rpa_render_order_admin_footer()`
- `rpa_handle_weight_confirmation_ajax()`

Existing helper ownership already present there:

- `rpa_render_weight_confirmation_box()`
- `rpa_order_screen_ids()`

## What changed in the monolith

`gastronom-stock-fix.php` now keeps hook wiring but delegates admin helper behavior to `rpa_*` when available for:

- admin footer assets / JS behavior
- hidden meta box ID list
- AJAX weight confirmation handler

## Why this cut is safe

- one semantic block only: preorder admin confirmation workflow helpers
- hooks stay in the old file
- no production activation change was required
- no storefront-facing behavior is affected

## Result

Admin confirmation UI ownership is now less fragmented:

- rendering helpers and admin assets are grouped in one extraction surface
- the monolith retains less embedded admin-specific JS/CSS
- the next admin hardening step can focus on the remaining hook wiring or product meta UI without reopening unrelated preorder/mail logic
