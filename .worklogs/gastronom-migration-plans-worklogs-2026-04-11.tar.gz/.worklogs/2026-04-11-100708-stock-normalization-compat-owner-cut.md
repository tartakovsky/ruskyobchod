# Stock Normalization Compat Owner Cut

Date: 2026-04-11 10:07:08 +0200

## Scope

Local-only architecture hardening.

No live deploy.

## What changed

- widened `mu-plugins/rusky-stock-normalization.php` with guarded compatibility wrappers for:
  - `gastronom_normalize_product_name()`
  - `gastronom_catalog_policy()`
  - `gastronom_reconcile_decimal_stock()`
  - `gastronom_apply_catalog_policy()`
  - `gastronom_enforce_product_rules()`
- converted the same functions in `plugins/gastronom-stock-fix/gastronom-stock-fix.php` into guarded fallback definitions via `if (!function_exists(...))`

## Result

- generic stock normalization and catalog-policy ownership now lives in `rusky-stock-normalization.php`
- `gastronom-stock-fix.php` keeps this slice only as fallback
- no storefront or live runtime change

## Next likely cut

- remaining residuals are mostly Dotypos-order-state entry points and hook-level orchestration inside `gastronom-stock-fix.php`
