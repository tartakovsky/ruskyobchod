# Dotypos Bridge Compat Owner Cut

Date: 2026-04-11 10:10:34 +0200

## Scope

Local-only architecture hardening.

No live deploy.

## What changed

- widened `mu-plugins/rusky-dotypos-stock-bridge.php` with guarded compatibility wrappers for:
  - `gastronom_apply_dotypos_stock_to_wc_product()`
  - `gastronom_resolve_dotypos_order_sync_quantity()`
  - `gastronom_sync_confirmed_preorder_items_to_dotypos()`
  - `gastronom_restore_confirmed_preorder_items_to_dotypos()`
- converted the same Dotypos bridge functions in `plugins/gastronom-stock-fix/gastronom-stock-fix.php` into guarded fallback definitions via `if (!function_exists(...))`

## Result

- delayed preorder Dotypos movement ownership now lives in `rusky-dotypos-stock-bridge.php`
- `gastronom-stock-fix.php` keeps this bridge slice only as fallback
- no storefront behavior changed and nothing new was deployed live
