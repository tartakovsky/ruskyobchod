## Context

Continuing the first real controlled migration step under the handoff rules:

- smallest safe surface
- preserve current hook graph where possible
- reduce ownership inside `gastronom-stock-fix.php` without changing behavior

## What changed

Performed the first live-compatible delegation move for generic stock normalization.

### `rusky-stock-normalization.php`

- aligned scaffold behavior with the current `gastronom-stock-fix.php` implementation
- specifically restored the service-product draft transition behavior inside `rsn_apply_catalog_policy()`
- aligned `rsn_enforce_product_rules()` signature with the existing `save_post_product` callback shape

### `gastronom-stock-fix.php`

These functions now delegate to `rsn_*` when available:

- `gastronom_normalize_product_name()`
- `gastronom_catalog_policy()`
- `gastronom_reconcile_decimal_stock()`
- `gastronom_apply_catalog_policy()`
- `gastronom_enforce_product_rules()`

Fallback logic remains in place inside `gastronom-stock-fix.php`.

## Why this is safe

- no hook registrations changed
- no function names used by the existing runtime changed
- if the new MU file is unavailable, the old behavior still exists in-place
- ownership starts moving toward `rsn_*` without requiring a risky one-shot extraction

## Result

This is the first actual migration from `gastronom-stock-fix.php` into a dedicated surface, not just scaffold creation.

## Next step

Continue with another low-risk delegation move of the same kind, likely:

- order-language helper delegation
or
- preorder helper/core delegation
