# 2026-04-11 01:45 preorder storefront wrapper cut

## Scope

Local-only hardening.

No live deploy in this step.

## Goal

Reduce anonymous WooCommerce storefront/preorder hook bodies in the monolith and replace them with named wrappers that delegate to the existing storefront owner.

## Changes

In:

- `/Users/alexandertartakovsky/Projects/gastronom-migration/plugins/gastronom-stock-fix/gastronom-stock-fix.php`

converted these anonymous callbacks into named wrapper functions:

- `gastronom_quantity_input_args()`
- `gastronom_add_to_cart_quantity()`
- `gastronom_add_to_cart_validation()`
- `gastronom_before_calculate_totals()`
- `gastronom_get_item_data()`
- `gastronom_render_single_product_note()`
- `gastronom_render_cart_notice()`
- `gastronom_available_payment_gateways()`
- `gastronom_price_html()`
- `gastronom_checkout_create_order()`
- `gastronom_checkout_create_order_line_item()`

Each now:

- delegates to
  `/Users/alexandertartakovsky/Projects/gastronom-migration/mu-plugins/rusky-preorder-storefront.php`
  through the existing `rpsf_*` owner functions when available
- keeps the previous inline logic as fallback compatibility

## Outcome

The preorder storefront/runtime block is now substantially less hidden inside anonymous hook bodies.

This makes the ownership boundary clearer:

- owner: `rusky-preorder-storefront.php`
- fallback compatibility: `gastronom-stock-fix.php`

## Next logical cut

Continue removing anonymous hook bodies and broadening guarded compatibility ownership in adjacent preorder/order slices only.
