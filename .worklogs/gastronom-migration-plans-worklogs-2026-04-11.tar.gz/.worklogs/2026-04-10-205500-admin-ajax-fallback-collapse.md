# Admin AJAX Fallback Collapse

## Scope

Local architecture hardening only.

No live deploy.

## Goal

Remove the duplicated inline AJAX fallback from the monolith once the dedicated admin owner already provides the handler.

## Change

Collapsed the fallback branch inside:

- `wp_ajax_gastronom_confirm_weight`

in:

- `/Users/alexandertartakovsky/Projects/gastronom-migration/plugins/gastronom-stock-fix/gastronom-stock-fix.php`

The hook callback now relies on:

- `rpa_handle_weight_confirmation_ajax()`

from:

- `/Users/alexandertartakovsky/Projects/gastronom-migration/mu-plugins/rusky-preorder-admin.php`

## Result

The admin confirmation workflow is less duplicated in the monolith and more clearly owned by the preorder admin extraction surface.
