# Алфавитная сортировка товаров RU/SK

**Date:** 2026-03-17 15:36
**Scope:** gastronom-stock-fix.php (v1.1→v1.2), gastronom-lang-switcher (v4.9), sort_products.py

## Summary
Реализована алфавитная сортировка товаров по языку. 701 товар получил мета-поля `_sort_sk` и `_sort_ru`. При переключении языка сортировка меняется автоматически. Сайт не сломан, сетка товаров работает.

## Context & Problem
Предыдущие две попытки сортировки (JS DOM v3.5-v3.9, PHP posts_clauses v4.0) сломали сайт. Восстановление заняло ~10 часов. Нужен безопасный подход.

## Decisions Made

### Мета-поля вместо SQL/DOM
- **Chose:** Pre-computed meta fields `_sort_sk` и `_sort_ru` + стандартный WooCommerce `pre_get_posts`
- **Why:** Не трогает SQL (posts_clauses), не трогает DOM (MutationObserver). Если что-то не так — удалить 10 строк PHP, сайт вернётся к popularity.

### Cookie для передачи языка PHP
- **Chose:** JS ставит cookie `gastronom_lang` из localStorage `gls-lang`
- **Why:** Плагин переключателя хранит язык в localStorage, но PHP не может его читать. Cookie — единственный способ.

### Перезагрузка при смене языка
- **Chose:** `location.reload()` только на страницах магазина/категории
- **Why:** PHP сортирует на сервере, без перезагрузки новый порядок не применится. На других страницах перезагрузка не нужна.

### Бэкап перед изменениями
- **Chose:** Ручной бэкап через Hostinger hPanel (2026-03-17 14:59)
- **Why:** Пользователь настоял на бэкапе после предыдущего 10-часового восстановления

## Компоненты

### 1. sort_products.py
- Получает все товары через WC REST API
- Разбирает двуязычные названия (разделитель " / ")
- Нормализует: SK — убрать диакритику, lowercase; RU — lowercase
- Записывает мета-поля `_sort_sk` и `_sort_ru`
- Режимы: dry (только парсинг), test (5 товаров), full (все)
- 19 товаров без разделителя — используют полное название

### 2. gastronom-stock-fix.php v1.2 (на сервере)
- Добавлен хук `pre_get_posts`: читает cookie `gastronom_lang`, ставит orderby=meta_value + meta_key=_sort_sk/_sort_ru
- Работает только на is_shop(), is_product_category(), is_product_tag()
- Не трогает админку

### 3. gastronom-lang-switcher gls-script.js
- При загрузке: ставит cookie `gastronom_lang` из localStorage
- При смене языка: обновляет cookie + перезагрузка на страницах магазина

## Open Questions
- Визуальная проверка в браузере не завершена (расширение Chrome отключалось)
- Dropdown «По популярности» всё ещё отображается — стоит ли его скрыть или обновить текст?
- Новые товары из Dotypos не получат мета-поля автоматически — нужен повторный запуск скрипта
