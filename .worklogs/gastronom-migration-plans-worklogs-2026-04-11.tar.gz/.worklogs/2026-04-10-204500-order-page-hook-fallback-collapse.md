# Order Page Hook Fallback Collapse

## Scope

Local architecture hardening only.

No live deploy.

## Goal

Remove duplicated order-page hook fallback behavior from monolith callbacks once dedicated `ropl_*` owners already exist.

## Change

Collapsed fallback branches inside these hook callbacks in:

- `/Users/alexandertartakovsky/Projects/gastronom-migration/plugins/gastronom-stock-fix/gastronom-stock-fix.php`

Hooks affected:

- `wp_head`
- early `template_redirect`
- later `template_redirect`

They now simply invoke:

- `ropl_render_forced_order_lang_marker()`
- `ropl_maybe_redirect_context_order_lang()`
- `ropl_start_order_page_buffer()`

when available, without carrying a second copy of the behavior in the callback body.

## Result

The order-page runtime block is now more clearly owned by:

- `/Users/alexandertartakovsky/Projects/gastronom-migration/mu-plugins/rusky-order-page-language.php`

and less duplicated in the monolith hook layer.
