# Commerce And Preorder Enable Compat Cut

Date: 2026-04-11 10:26:32 +0200

## Scope

Local-only architecture hardening.

No live deploy.

## What changed

- widened `mu-plugins/rusky-commerce-adjustments.php` with guarded compatibility wrappers for:
  - `gastronom_add_cod_fee()`
  - `gastronom_gateway_description()`
  - `gastronom_render_checkout_payment_refresh_script()`
- widened `mu-plugins/rusky-weight-preorder.php` with guarded compatibility wrapper for:
  - `gastronom_weight_preorder_enabled()`
- converted the same functions in `plugins/gastronom-stock-fix/gastronom-stock-fix.php` into guarded fallback definitions

## Result

- the commerce adjustment surface now lives in the commerce owner file instead of only delegating inward from the monolith
- preorder enable-check ownership now lives in the preorder owner file
- `gastronom-stock-fix.php` lost another small direct-ownership slice without any live change
