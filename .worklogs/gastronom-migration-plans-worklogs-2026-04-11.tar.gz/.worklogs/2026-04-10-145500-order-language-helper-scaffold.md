## Context

Implementing the first small extraction-ready code surface from the hardening plan without touching the live preorder flow.

The goal here was not to migrate behavior yet.
The goal was to create a safe helper boundary that the future preorder extraction can use.

## What was done

Added a new scaffold MU file:

- `/Users/alexandertartakovsky/Projects/gastronom-migration/mu-plugins/rusky-order-language-helpers.php`

## Design choices

- Used `rslh_*` function names instead of `gastronom_*`.
- This avoids function-redeclaration fatals while `gastronom-stock-fix.php` still owns the live logic.
- The file mirrors the minimal helper surface identified in the previous inventory:
  - current/order language lookup
  - short RU/SK text helpers
  - order locale wrapper
  - bilingual title localization
  - localized order/shipping/payment label mapping

## Important limitation

This is scaffold-only for now.

- no existing calls were redirected to this file yet
- no production behavior should change from adding this file alone

## Next step

Plan the first controlled call-site migration from `gastronom_*` to `rslh_*` for the preorder flow, or decide whether to keep the scaffold as reference until the larger preorder extraction starts.
