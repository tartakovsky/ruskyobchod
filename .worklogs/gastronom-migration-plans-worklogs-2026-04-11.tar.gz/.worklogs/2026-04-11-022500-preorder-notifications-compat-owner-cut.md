# 2026-04-11 02:25 preorder notifications compat owner cut

## Scope

Local-only hardening.

No live deploy in this step.

## Goal

Apply the guarded-owner compatibility pattern to the preorder notifications / transition surface.

## Changes

Expanded:

- `/Users/alexandertartakovsky/Projects/gastronom-migration/mu-plugins/rusky-preorder-notifications.php`

It now exposes guarded compatibility wrappers for:

- `gastronom_send_preorder_created_emails()`
- `gastronom_send_weight_confirmation_email()`
- `gastronom_mark_weight_confirmed_order_ready()`

Reduced monolith ownership in:

- `/Users/alexandertartakovsky/Projects/gastronom-migration/plugins/gastronom-stock-fix/gastronom-stock-fix.php`

Those same functions are now wrapped in `if (!function_exists(...))`, so the notifications owner can define them first and the monolith becomes guarded fallback there too.

## Outcome

The preorder notifications / transition slice now follows the same ownership pattern as the other extracted helper areas.
