## Context

After extracting preorder helper, state, bridge, language, notification, and order-page helper surfaces, the next residual preorder-specific helper block in the monolith was admin confirmation UI support.

This remained a good extraction target because the helper functions were still distinct from the actual live admin hook wiring.

## What changed

Added a new extraction-ready scaffold:

- `mu-plugins/rusky-preorder-admin.php`

With new helper names:

- `rpa_render_weight_confirmation_box()`
- `rpa_order_screen_ids()`

Inside `plugins/gastronom-stock-fix/gastronom-stock-fix.php`, these entry points now delegate to `rpa_*` when available:

- `gastronom_render_weight_confirmation_box()`
- `gastronom_order_screen_ids()`

Fallback implementations remain in-place.

## Why this is safe

- no admin hooks were rewired
- existing runtime entry points remain under the old `gastronom_*` names
- only helper ownership shifts when the scaffold MU file is present
- if the scaffold MU file is missing, behavior still falls back to the original implementation

## Result

The preorder admin helper surface now has a dedicated ownership target outside the monolith, leaving mostly hook-heavy integration code behind in `gastronom-stock-fix.php`.

## Next step

Review whether the remaining hook-heavy surfaces should stay in place for now or whether a final local hook-registration shim is justified later.
