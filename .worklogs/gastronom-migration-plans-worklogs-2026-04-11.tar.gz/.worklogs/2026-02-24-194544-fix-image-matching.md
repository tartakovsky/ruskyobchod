# Переписал скрипт сопоставления изображений с мульти-стратегией

**Date:** 2026-02-24 19:45
**Scope:** match_images.py, image_assignments.json, unmatched_products.json

## Summary
Rewrote match_images.py to use 6 matching strategies instead of slug-only. Results improved from 4 matched products to 91, with 83 image assignments written.

## Context & Problem
Old site (ruskyobchod.sk) and new site (hostinger) have completely different slugs for the same products. Names follow a bilingual pattern (Slovak/Russian) but use different separators (old: `.`, new: `/`), different formatting, and slightly different wording.

## Decisions Made

### Multi-strategy matching with declining specificity
- **Chose:** 6-level cascade: slug -> exact name -> normalized name -> fuzzy Russian -> fuzzy Slovak -> fuzzy full name
- **Why:** Each level catches different cases. Slug/exact catches identical products, fuzzy catches reformatted ones.

### Fuzzy threshold 0.82-0.85 for parts, 0.75 for full name
- **Chose:** Dynamic threshold based on name length (0.85 for short names, 0.82 for longer)
- **Why:** Short names have higher false positive rate. Testing showed 0.80 caught some wrong matches (e.g. "Ikra Keta" matching "Ikra Pstruch"). 0.82 is a reasonable tradeoff.

### Improved bilingual name splitting
- **Chose:** Multiple split strategies: `/`, `. `, script boundary detection (Latin->Cyrillic transition)
- **Why:** Old site uses `.` as separator (428 products), sometimes without space. Script boundary detection catches edge cases.

## Open Questions / Future Considerations
- ~2-3 fuzzy matches may be false positives (similar but different products)
- 359 old products remain unmatched — many genuinely don't exist on new site
- Could add manual override list for known mismatches

## Next Steps
1. Review image_assignments.json for obvious errors
2. Use assignments to actually set images via WooCommerce API
3. Handle the 8 images not found in media library (may need re-upload)
