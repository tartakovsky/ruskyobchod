## Context

After moving preorder helper/core calculations toward `rwp_*`, a small but still important residual preorder state-helper surface remained inside `gastronom-stock-fix.php`.

These helpers still belonged logically to the preorder module, but they did not require any live hook rewiring yet.

## What changed

Extended `mu-plugins/rusky-weight-preorder.php` with:

- `rwp_normalize_order_state()`
- `rwp_product_has_preorder_weight()`
- `rwp_order_has_preorder_weight()`

Inside `plugins/gastronom-stock-fix/gastronom-stock-fix.php`, these entry points now delegate to `rwp_*` when available:

- `gastronom_normalize_preorder_order_state()`
- `gastronom_product_has_preorder_weight()`
- `gastronom_order_has_preorder_weight()`

Fallback implementations remain in-place.

## Why this is safe

- existing hooks and entry points were not renamed or rewired
- stateful runtime still enters through the old `gastronom_*` functions
- only ownership of helper/state logic shifts when the scaffold MU file is present
- if the scaffold MU file is missing, behavior still falls back to the original implementation

## Result

More of the preorder state machine now has an extraction-ready home outside the monolithic plugin file, while the live runtime graph remains stable.

## Next step

Keep the remaining preorder-specific surfaces separated by type:

- admin confirmation UI / order-screen helpers
- confirmation email rendering / sending
- final state-transition orchestration after weight confirmation
