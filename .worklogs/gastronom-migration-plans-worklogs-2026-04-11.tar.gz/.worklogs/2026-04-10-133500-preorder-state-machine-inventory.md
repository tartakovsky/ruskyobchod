## Context

Continuing architecture hardening with the constraint that cleanup comes first and broader integration work stays deferred.

This pass followed the earlier handoff rules:

- read first
- document before broad refactor
- isolate one semantic block at a time

## What was done

Performed a dedicated read-only inventory of the variable-weight preorder flow inside:

- `/Users/alexandertartakovsky/Projects/gastronom-migration/plugins/gastronom-stock-fix/gastronom-stock-fix.php`

## Findings

- The preorder flow is a real state machine, not just a couple of helper hooks.
- It has a clean high-level lifecycle:
  - preorder-enabled product
  - order created with preorder item metadata
  - Woo-only piece reservation
  - `await-weight`
  - manager confirms actual weight
  - totals recalculated
  - delayed Dotypos sync
  - status moves to `pending` or `on-hold`
- This flow is separable from:
  - decimal stock normalization
  - storefront messaging
  - catalog policy
  - generic runtime overrides

## Important caveats

- `gastronom_restore_preorder_site_stock()` exists but its active hook registration is not visible in the current file snapshot.
- The preorder flow still depends on helper functions in the same file for language-aware messaging.
- The old `_gls_weighted` model remains a separate overlap risk outside this state machine.

## Artifact

- Added:
  - `/Users/alexandertartakovsky/Projects/gastronom-migration/.plans/2026-04-10-gastronom-preorder-state-machine.md`

## Next step

Inventory which language/order-localization helpers are genuinely required by preorder handling so the future extraction does not drag unnecessary language-layer logic into the new boundary.
