# Update _gls_weighted meta for 66 product types

**Date:** 2026-03-15 17:25
**Scope:** update_gls_weighted.py, WooCommerce REST API

## Summary
Reset _gls_weighted=yes to no for all 191 products that had it, then set _gls_weighted=yes for 136 products (66 product types, many duplicated in old/new site products) matching the specified list of weighted candy, caramel, fish, and meat products.

## Context & Problem
The _gls_weighted meta flag was set too broadly on ~191 products including false positives like chocolates, waters, sauces, jams, and cakes. Needed to restrict it to only the 66 specified product types (конфеты, карамель, рыба, сало, снеки, буженина, финики, грузди, осетр).

## Decisions Made

### Tight name matching with category prefixes
- **Chose:** Require Russian category prefix (Конфеты, Карамель, Рыба, etc.) in product name
- **Why:** Prevents false positives like "Шоколад Аленка" matching "Аленка", "Торт Белочка" matching "Белочка", "Вода Газ. Барбарис" matching "Барбарис"

### Exclusions for ambiguous names
- **Chose:** Explicit exclusions for "Птичье Молоко н-р" (boxed set), "халва Азовская" (different product)
- **Why:** These contain matching substrings but are different products

## Open Questions / Future Considerations
- If new products are added, the script would need to be re-run or the list updated
