## Context

Continuing the main architecture-hardening track using the safe extraction rules from the handoff pack.

After the language-helper scaffold and preorder-core scaffold were added, the next safest move was to finish the remaining extraction-ready surfaces without touching live hook wiring yet.

## What was done

Added two scaffold-only MU files:

- `/Users/alexandertartakovsky/Projects/gastronom-migration/mu-plugins/rusky-dotypos-stock-bridge.php`
- `/Users/alexandertartakovsky/Projects/gastronom-migration/mu-plugins/rusky-stock-normalization.php`

## Why this is safe

- no existing `gastronom_*` functions were removed
- no existing hook registrations were changed
- no checkout/order/runtime path changed
- all new functions use distinct prefixes:
  - `rdsb_*`
  - `rsn_*`

## What this accomplishes

The intended split of `gastronom-stock-fix.php` now exists in code as four local scaffold surfaces:

- order/preorder language helpers
- preorder core
- Dotypos bridge
- stock normalization

This means the next stage is no longer “invent the structure”.
The next stage is controlled migration of ownership from `gastronom_*` into those surfaces.

## Next step

Choose the first real low-risk migration boundary:

- either keep building scaffolds until every target function has a destination
- or start the first controlled call-site migration for generic stock normalization, which is likely safer than preorder stateful hooks
