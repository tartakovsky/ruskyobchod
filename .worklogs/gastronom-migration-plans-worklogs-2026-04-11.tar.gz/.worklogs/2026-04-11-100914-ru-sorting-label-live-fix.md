# RU Sorting Label Live Fix

Date: 2026-04-11 10:09:14 +0200

## Scope

Single-file live fix for category sorting label localization.

## Broken behavior

- on RU category pages the sorting dropdown still rendered the alphabetical option in Slovak:
  - `Podľa abecedy`

## Root cause

- `mu-plugins/rusky-product-sorting.php`
  hardcoded the `alphabetical` catalog-order label in Slovak
- the first patch that depended on current runtime language was still too late for this hook path
- the working discriminator for this surface is the direct `?lang=...` request param, with fallback to runtime/cookie

## Live change

- updated only:
  - `mu-plugins/rusky-product-sorting.php`
- `rps_catalog_orderby()` now resolves language in this order:
  - `$_GET['lang']`
  - runtime helper / cookie fallback
- output label is now:
  - `По алфавиту` for RU
  - `Podľa abecedy` for SK

## Verification

HTTP verification:

- `https://ruskyobchod.sk/kategoria-produktu/sneki-snacky/?lang=ru&sort_verify=1`
  contains `По алфавиту`
- `https://ruskyobchod.sk/kategoria-produktu/sneki-snacky/?lang=sk&sort_verify=1`
  contains `Podľa abecedy`

Browser verification:

- live Chrome snapshot on
  `https://ruskyobchod.sk/kategoria-produktu/sneki-snacky/?lang=ru&sort_verify=2`
  shows the category combobox option:
  - `По алфавиту`
