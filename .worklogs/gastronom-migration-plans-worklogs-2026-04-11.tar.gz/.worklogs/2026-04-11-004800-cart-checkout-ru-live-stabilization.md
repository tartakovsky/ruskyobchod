# 2026-04-11 00:48 cart/checkout RU live stabilization

## Scope

Live quick-fix work only, still following the `handoff.zip` constraints:

- smallest possible surface
- one file per deploy
- immediate browser verification in the exact broken user path

## Files changed on live

1. `/home/u595644545/domains/ruskyobchod.sk/public_html/wp-content/mu-plugins/rusky-storefront-messaging.php`
2. `/home/u595644545/domains/ruskyobchod.sk/public_html/wp-content/mu-plugins/rusky-commerce-adjustments.php`
3. `/home/u595644545/domains/ruskyobchod.sk/public_html/wp-content/plugins/gastronom-lang-switcher/gastronom-lang-switcher.php`

## Why

The user-reported RU storefront defects were reproduced directly in browser:

- category free-shipping banner stayed Slovak on RU category pages
- cart and checkout still showed mixed Slovak/English labels in shipping and payment methods
- cart/checkout shell still had duplicated `skip-link`, untranslated footer brand, untranslated cookie accept button, and checkout breadcrumb/title residuals

## Changes

### `rusky-storefront-messaging.php`

- moved the free-shipping banner to server-side language selection
- removed the previous SK-visible + RU-hidden dual-span output

Verified result:

- RU category page shows `Бесплатная доставка при заказе от 100 €!`

### `rusky-commerce-adjustments.php`

- added `rca_current_lang()`
- added `rca_localize_label()` for known shipping/payment strings
- localized:
  - `Osobne vyzdvihnutie`
  - `GLS doručenie na adresu`
  - `SK Packeta Pick-up Point (Z-Point, Z-Box)`
  - `GLS Balíkomat`
  - `Platba pri doručení`
  - `Bankový prevod`
  - `Card`
- applied that localization through:
  - `woocommerce_cart_shipping_method_full_label`
  - `woocommerce_gateway_title`
- changed pickup-note output to one server-selected string instead of SK + hidden RU spans

Verified result:

- cart and checkout show RU shipping/payment labels
- pickup-note lines are RU
- WooPayments title now shows `Оплата картой`

### `gastronom-lang-switcher.php`

- removed logged-in frontend exclusion that was leaving homepage bilingual
- added active-state class to RU/SK switcher
- normalized `skip-link` markup more broadly
- extended server-rendered shell normalization for:
  - `skip-link`
  - footer `Gastronom` heading
  - cookie `Ok` button
  - checkout `Objednávka` title/breadcrumb path

Verified result:

- homepage logged-in RU path is no longer bilingual
- RU switcher button is visibly active
- `skip-link` is single-text on homepage/cart/checkout
- footer brand is `Гастроном`
- cookie button is `Ок`
- checkout breadcrumb/title path is `Оформление заказа`

## Browser verification

Verified in Chrome DevTools on these live routes:

- `https://ruskyobchod.sk/?lang=ru`
- `https://ruskyobchod.sk/kategoria-produktu/sneki-snacky/?lang=ru`
- `https://ruskyobchod.sk/cart/?lang=ru`
- `https://ruskyobchod.sk/checkout/?lang=ru`

Verified user-visible outcomes:

- homepage hero/body is RU-only in logged-in frontend
- category free-shipping banner is RU
- cart shipping methods are RU
- checkout payment labels are RU
- checkout breadcrumb reads `Гастроном Оформление заказа`

## Remaining observed residuals

- `GLS ParcelShop` remains branded English, which is acceptable for now
- some legal/geo/company proper nouns remain Slovak where appropriate
- no new live hardening should be mixed in before the next storefront defect is reproduced and isolated the same way
