# 2026-04-11 01:15 order language compat owner cut

## Scope

Local-only hardening.

No live deploy in this step.

## Goal

Make the order-language owner file authoritative not only for `rslh_*` helpers, but also for the compatibility surface currently consumed by the monolith.

## Changes

Expanded:

- `/Users/alexandertartakovsky/Projects/gastronom-migration/mu-plugins/rusky-order-language-helpers.php`

It now also exposes guarded compatibility wrappers for:

- `gastronom_current_lang()`
- `gastronom_order_lang()`
- `gastronom_tt()`
- `gastronom_t()`
- `gastronom_locale_for_order()`
- `gastronom_with_order_locale()`
- `gastronom_split_bilingual_title()`
- `gastronom_localize_title()`
- `gastronom_localize_order_label()`

Reduced monolith ownership in:

- `/Users/alexandertartakovsky/Projects/gastronom-migration/plugins/gastronom-stock-fix/gastronom-stock-fix.php`

Those same `gastronom_*` helper definitions are now wrapped in `if (!function_exists(...))`, so the owner file can define them first and the monolith becomes guarded fallback rather than the primary home for that surface.

## Outcome

The order-language compatibility surface is now explicitly ownable by:

- `/Users/alexandertartakovsky/Projects/gastronom-migration/mu-plugins/rusky-order-language-helpers.php`

This is a cleaner contract for future hardening:

- MU owner can become the real source of truth
- monolith can continue shrinking behind guarded fallback definitions

## Next logical cut

Continue along the same pattern for adjacent owner-backed helper surfaces only, without mixing this local hardening with new live storefront changes.
