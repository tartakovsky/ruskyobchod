# Preorder Product Meta Controlled Migration

## Scope

Local architecture hardening only.

No live deploy.
No storefront change.
No runtime switch.

## Goal

Move the preorder product-meta admin surface out of:

- `/Users/alexandertartakovsky/Projects/gastronom-migration/plugins/gastronom-stock-fix/gastronom-stock-fix.php`

and into the existing preorder admin owner file:

- `/Users/alexandertartakovsky/Projects/gastronom-migration/mu-plugins/rusky-preorder-admin.php`

## What moved

New helper ownership added to `rusky-preorder-admin.php`:

- `rpa_render_product_preorder_fields()`
- `rpa_save_product_preorder_fields()`

These now own:

- `_gastronom_weight_preorder` field rendering
- min/max kg admin fields
- customer note admin field
- save handling for those fields
- `_gls_weighted` reset on enable
- initial piece-stock refresh on enable

## What stayed in the monolith

`gastronom-stock-fix.php` still owns the Woo hooks, but those hooks now delegate to `rpa_*` when present for:

- `woocommerce_product_options_general_product_data`
- `woocommerce_process_product_meta`

## Result

The preorder admin surface is now less split:

- product-meta UI
- order confirmation box
- admin footer assets
- hidden meta-box policy
- AJAX confirmation handler

are all grouped under the same extraction surface:

- `rusky-preorder-admin.php`

This reduces the remaining admin-only weight inside the monolith without changing live runtime today.
