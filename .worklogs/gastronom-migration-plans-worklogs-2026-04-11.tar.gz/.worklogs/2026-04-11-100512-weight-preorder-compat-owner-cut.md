# Weight Preorder Compat Owner Cut

Date: 2026-04-11 10:05:12 +0200

## Scope

Local-only architecture hardening.

No live deploy.

## What changed

- widened `mu-plugins/rusky-weight-preorder.php` from `rwp_*` helper core into guarded compatibility-owner surface for:
  - `gastronom_weight_preorder_min_kg()`
  - `gastronom_weight_preorder_max_kg()`
  - `gastronom_weight_preorder_avg_kg()`
  - `gastronom_weight_preorder_price_per_kg()`
  - `gastronom_weight_preorder_reserved_qty()`
  - `gastronom_weight_preorder_piece_capacity()`
  - `gastronom_apply_preorder_piece_stock()`
  - `gastronom_preorder_item_is_confirmed()`
  - `gastronom_normalize_preorder_order_state()`
  - `gastronom_product_has_preorder_weight()`
  - `gastronom_order_has_preorder_weight()`
  - `gastronom_order_requires_weight_confirmation()`
  - `gastronom_reserve_preorder_site_stock()`
  - `gastronom_restore_preorder_site_stock()`
- added owner-native `rwp_reserve_site_stock()` and `rwp_restore_site_stock()` so the preorder stock reservation path is no longer owned only by the monolith
- converted the same `gastronom_*` functions in `plugins/gastronom-stock-fix/gastronom-stock-fix.php` into guarded fallback definitions via `if (!function_exists(...))`

## Result

- preorder weight/state/site-reservation ownership now lives in `rusky-weight-preorder.php`
- `gastronom-stock-fix.php` keeps fallback behavior only for this slice
- storefront/runtime behavior unchanged because nothing was deployed live

## Next likely cut

- reduce remaining stock/order-state residuals in `gastronom-stock-fix.php`
- then decide whether the next safe boundary is `rusky-stock-normalization.php` compatibility wrappers or the remaining Dotypos-order state entry points
