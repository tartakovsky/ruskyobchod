# Order Admin Hook Wiring Owner Cut

Date: 2026-04-11 10:21:32 +0200

## Scope

Local-only architecture hardening.

No live deploy.

## What changed

- removed remaining anonymous hook callbacks from the order-page/admin residual zone in `plugins/gastronom-stock-fix/gastronom-stock-fix.php`
- converted these hooks to named guarded callbacks:
  - `woocommerce_order_item_name`
  - `wp_head`
  - `template_redirect` x2
  - `woocommerce_order_item_meta_end`
  - `admin_footer`
  - `add_meta_boxes`
  - `woocommerce_admin_order_data_after_order_details`
  - `wp_ajax_gastronom_confirm_weight`
- widened owner files with matching compatibility wrappers:
  - `mu-plugins/rusky-order-page-language.php`
  - `mu-plugins/rusky-preorder-admin.php`

## Result

- order-page and preorder-admin hook wiring is now owner-backed instead of anonymous-monolith-backed
- `gastronom-stock-fix.php` became more predictable and easier to diff
- no live storefront or admin behavior changed because nothing was deployed
