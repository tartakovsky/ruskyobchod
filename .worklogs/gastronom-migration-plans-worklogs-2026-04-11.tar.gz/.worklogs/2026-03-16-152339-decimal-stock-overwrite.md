# Дробные остатки, dotypos_product_id, удаление дубликатов, Overwrite

**Date:** 2026-03-16 15:23
**Scope:** Dotypos plugin (dotypos.php), gastronom-lang-switcher.php, WC products, Dotypos API

## Summary
Исправлена синхронизация остатков: заполнен dotypos_product_id у 702 товаров, добавлен EAN к 104 товарам в Dotypos POS, исправлен плагин Dotypos для поддержки дробных остатков весовых товаров. Удалены дубликаты и системные товары. Overwrite from Dotypos теперь работает полностью.

## Context & Problem
1. Overwrite from Dotypos не обновлял остатки — у товаров отсутствовало мета-поле dotypos_product_id
2. ~104 товара в Dotypos не имели EAN — синхронизация невозможна
3. Весовые товары с дробным остатком (0.4 кг) округлялись до 0 → outofstock
4. 3 лишних товара на сайте (дубликат + 2 системных)

## Decisions Made

### dotypos_product_id через Dotypos API
- **Chose:** Получить все productId из Dotypos Cloud API v2, сопоставить с WC по EAN/SKU, записать как мета-поле
- **Why:** Плагин Dotypos матчит товары по этому полю (не по SKU) при Overwrite

### EAN для товаров без штрихкода
- **Chose:** Записать productId как EAN в Dotypos через API (PATCH с ETag)
- **Why:** Плагин матчит по EAN при webhook-синхронизации, товары без EAN не синхронизируются

### Дробные остатки — патч dotypos.php
- **Chose:** Заменить wc_update_product_stock() на прямой update_post_meta() в функции overwrite
- **Why:** WooCommerce wc_stock_amount() делает intval() ПЕРЕД фильтром, дробные значения теряются. Прямая запись в мета обходит эту проблему

### Удаление лишних товаров
- **Chose:** Удалены WC#10255 (дубликат Бабаевские), WC#10103 (EOS Doprava), WC#10102 (EOS Obaly), WC#10110 (дубликат Помидоры)
- **Why:** Дубликаты и системные товары (доставка/упаковка) не нужны на сайте

## Open Questions
- REST API возвращает stock_quantity как int (0 для 0.4) — визуально товар instock, но qty в API некорректный
- В кассе 2 дубликата помидоров "Моя семья" с одинаковым EAN — нужно удалить один в Dotypos
- Аджика Сухая — пользователь проверяет дубликат ли это
