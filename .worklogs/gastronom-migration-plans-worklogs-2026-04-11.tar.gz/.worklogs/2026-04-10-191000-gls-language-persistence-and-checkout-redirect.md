# GLS Language Persistence And Checkout Redirect

## Scope

One narrow live-safe block only:

- restore language persistence in the re-enabled `gastronom-lang-switcher`
- preserve `lang` across internal redirects
- verify the empty-checkout redirect path immediately

## Problem observed

- `https://ruskyobchod.sk/cart/?lang=ru` rendered correctly in Russian
- `https://ruskyobchod.sk/checkout/?lang=ru` returned a WordPress `302` to `/cart/`
- the redirect dropped `lang`
- the resulting empty-cart page rendered in Slovak

This was not a cart translation defect by itself.
It was a language-state loss on the checkout-to-cart redirect path.

## Local change

Updated:

- `/Users/alexandertartakovsky/Projects/gastronom-migration/gastronom-lang-switcher/gastronom-lang-switcher.php`

Added two minimal mechanisms back into the main plugin runtime:

1. On `init`, when `?lang=ru|sk` is present, persist it into the `gastronom_lang` cookie.
2. On `wp_redirect`, append the current `lang` only for same-site redirects.

No new MU ownership was introduced.
No runtime owner was switched.
No emergency layer was expanded.

## Live procedure

1. Uploaded local plugin file to `~/tmp-gls-stage2.php`
2. Verified on server:
   - `php -l ./tmp-gls-stage2.php`
3. Backed up live plugin:
   - `gastronom-lang-switcher.php.pre-cookie-redirect-2026-04-10-1912`
4. Replaced only live:
   - `/home/u595644545/domains/ruskyobchod.sk/public_html/wp-content/plugins/gastronom-lang-switcher/gastronom-lang-switcher.php`

## Immediate verification

- `https://ruskyobchod.sk/` -> `200`
- `https://ruskyobchod.sk/wp-login.php` -> `200`
- `https://ruskyobchod.sk/checkout/?lang=ru&gls_verify=15` -> `302`
  - `Set-Cookie: gastronom_lang=ru`
  - `Location: https://ruskyobchod.sk/cart/?lang=ru`
- final empty-cart HTML after following redirect rendered in Russian:
  - `Корзина`
  - `Ваша корзина пока пуста.`
  - `Вернуться в магазин`

## Residual issues after this block

- front page still has a duplicate skip-link structure in raw HTML
- cart/checkout still retain theme chrome on empty states:
  - `bradcrumbs`
  - `vw-page-title`
- broader checkout translation polish remains pending for non-empty checkout flows

## Rule check

- smallest safe surface first: kept
- one semantic block at a time: kept
- immediate verification after live change: kept
- emergency layer freeze respected: kept
