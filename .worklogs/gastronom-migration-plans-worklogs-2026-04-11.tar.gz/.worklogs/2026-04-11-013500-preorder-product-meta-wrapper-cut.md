# 2026-04-11 01:35 preorder product meta wrapper cut

## Scope

Local-only hardening.

No live deploy in this step.

## Goal

Reduce anonymous admin/product-meta hook bodies in the monolith and make the preorder product-meta block easier to own and delegate.

## Changes

In:

- `/Users/alexandertartakovsky/Projects/gastronom-migration/plugins/gastronom-stock-fix/gastronom-stock-fix.php`

replaced anonymous hook callbacks with named wrappers:

- `gastronom_render_product_preorder_fields()`
- `gastronom_save_product_preorder_fields()`

These wrappers now:

- delegate to
  `/Users/alexandertartakovsky/Projects/gastronom-migration/mu-plugins/rusky-preorder-admin.php`
  via:
  - `rpa_render_product_preorder_fields()`
  - `rpa_save_product_preorder_fields()`
- keep the previous inline fallback behavior for compatibility

## Outcome

The preorder product-meta admin slice is now more consistent with the rest of the hardening work:

- owner-backed when the MU surface is available
- fallback-compatible when it is not
- no longer hidden inside anonymous hook bodies

## Next logical cut

Continue removing anonymous hook bodies and widening named delegation surfaces in adjacent preorder admin/storefront blocks only.
