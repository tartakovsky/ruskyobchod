# 2026-04-11 01:05 commerce adjustments owner cut

## Scope

Local-only architecture hardening after the live RU storefront stabilization.

No live deploy in this step.

## Goal

Reduce `gastronom-stock-fix.php` ownership in the checkout commerce-adjustment area by moving a coherent runtime block into the existing owner:

- `/Users/alexandertartakovsky/Projects/gastronom-migration/mu-plugins/rusky-commerce-adjustments.php`

## Changes

Expanded `rusky-commerce-adjustments.php` ownership to include:

- COD fee application:
  - `rca_add_cod_fee()`
- checkout payment refresh script:
  - `rca_render_checkout_payment_refresh_script()`
- existing payment/shipping label and gateway-description localization remained there as the same commerce surface

Reduced `gastronom-stock-fix.php` in the same block:

- replaced anonymous hooks with named wrappers:
  - `gastronom_add_cod_fee()`
  - `gastronom_gateway_description()`
  - `gastronom_render_checkout_payment_refresh_script()`
- wrappers now delegate to `rca_*` owners when present
- fallback behavior remains in the monolith for controlled compatibility

## Outcome

The checkout commerce-adjustment slice is now more clearly owned by:

- `/Users/alexandertartakovsky/Projects/gastronom-migration/mu-plugins/rusky-commerce-adjustments.php`

while `gastronom-stock-fix.php` has a thinner compatibility surface in that area.

## Next logical local cut

Continue shrinking the monolith around adjacent commerce/order language helpers only after the current owner surfaces are stable and documented.
