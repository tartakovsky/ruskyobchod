# Dotypos Wrapper Reference Audit

Date: 2026-04-11 10:35:09 +0200

## Scope

Local-only reference audit for the two most suspicious compatibility wrappers in the shell layer:

- `gastronom_apply_dotypos_stock_to_wc_product()`
- `gastronom_resolve_dotypos_order_sync_quantity()`

## Result

Repo-local search confirms:

- no additional repo-local call sites were found outside:
  - `mu-plugins/rusky-dotypos-stock-bridge.php`
  - `plugins/gastronom-stock-fix/gastronom-stock-fix.php`

## Implication

- these functions currently behave as compatibility wrappers / extension points
- they must not be removed just because repo-local references are sparse
- deletion requires a separate live/vendor wiring audit, not just repo grep

## Decision

- keep both wrappers in the monolith shell for now
- classify them as shim-retention functions, not cleanup targets
