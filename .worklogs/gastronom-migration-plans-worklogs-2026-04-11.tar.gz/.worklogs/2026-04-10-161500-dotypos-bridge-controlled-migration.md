## Context

Continuing the same controlled-migration pattern after moving preorder helper/core ownership toward `rwp_*`.

The next lowest-risk boundary was the Dotypos preorder bridge surface.

## What changed

Inside `plugins/gastronom-stock-fix/gastronom-stock-fix.php`, these entry points now delegate to `rdsb_*` when available:

- `gastronom_apply_dotypos_stock_to_wc_product()`
- `gastronom_resolve_dotypos_order_sync_quantity()`
- `gastronom_sync_confirmed_preorder_items_to_dotypos()`
- `gastronom_restore_confirmed_preorder_items_to_dotypos()`

Fallback implementations remain in-place.

## Why this is safe

- existing hook registrations were not changed
- the old `gastronom_*` runtime entry points remain the control surface
- Dotypos behavior only shifts when the scaffold MU file is present
- if the scaffold MU file is missing, behavior still falls back to the original implementation

## Result

The preorder-specific Dotypos movement logic now has an extracted ownership target, while the live plugin file still preserves the current runtime graph.

## Next step

Review the remaining stateful surface in the monolith and separate:

- pure helper/state-normalization functions that can move next
- live admin/UI/hook wiring that should stay in place for now
