# Настройка Slovenská pošta ePodací hárok

**Date:** 2026-03-17 12:44
**Scope:** WooCommerce, ePodací hárok plugin, mojezasielky.posta.sk

## Summary
Полностью настроен плагин Slovenská pošta - ePodací hárok v1.4.6 в WP Admin. Активирован WebEPH API на mojezasielky.posta.sk, получены и введены User ID и API Key. Заполнены все данные отправителя B.A.A.B. s.r.o.

## Context & Problem
Плагин был установлен и активирован, но не настроен. Страница настроек не находилась — оказалось, slug = `spirit-eph`, URL: `options-general.php?page=spirit-eph`. Ранее пробовали `sp-eph` — неверный slug.

## Decisions Made

### Страница настроек плагина
- **Chose:** `options-general.php?page=spirit-eph`
- **Why:** Код плагина (includes/admin.php) использует `add_options_page()` со slug `spirit-eph`

### Активация WebEPH API
- **Chose:** Активирован чекбокс на mojezasielky.posta.sk → #settings
- **Why:** API ключи появляются только после активации

### API Credentials
- **userId:** 696B9A0BBFF73438C08BACFB
- **apiKey:** 7D462AF613E7C794E7117ECFDFD00E0711FD60DEC419F000D5BB2F803D8B70B2

### Настройки плагина
- **Meno:** Aleksandr Tartakovskii
- **Organizácia:** B.A.A.B. s.r.o.
- **Adresa:** Zámocká 5, 81101 Bratislava, SK
- **Telefón:** 0948017819
- **Email:** gastronom@trtk.me
- **Číslo účtu:** SK9775000000004034983445
- **Typ EPH:** EPH
- **Spôsob spracovania:** 3 (Podaj na pošte)
- **Spôsob úhrady:** 5 (Platené v hotovosti)
- **Trieda:** 2 (Druhá trieda)
- **Predvolený druh zásielky:** Balík na adresu (для всех зон)
- **SendTrackingNo:** включен (подачное число в email)
- **PaymentType:** Оплата при доставке (cod)
- **RovnakaNavratova:** включен (обратный адрес = адрес отправителя)

## Open Questions
- Slovenská pošta не добавлена как shipping method в WooCommerce зоне "Словакия" — плагин работает через bulk actions в заказах (экспорт XML), а не как отдельный shipping method
- Нужно проверить реальный экспорт заказа в XML для подачи на mojezasielky.posta.sk
