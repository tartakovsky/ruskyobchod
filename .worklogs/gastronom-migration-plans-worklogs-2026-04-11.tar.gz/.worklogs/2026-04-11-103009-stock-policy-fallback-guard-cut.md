# Stock Policy Fallback Guard Cut

Date: 2026-04-11 10:30:09 +0200

## Scope

Local-only architecture hardening.

No live deploy.

## What changed

- after adding `mu-plugins/rusky-stock-policy.php`, converted the matching setup/policy functions in `plugins/gastronom-stock-fix/gastronom-stock-fix.php` into guarded fallback definitions via `if (!function_exists(...))`
- corrected a local guard duplication introduced during that conversion

## Result

- the stock-policy/bootstrap slice is now truly fallback-only inside the monolith
- `gastronom-stock-fix.php` moved one step closer to a pure compatibility shell
