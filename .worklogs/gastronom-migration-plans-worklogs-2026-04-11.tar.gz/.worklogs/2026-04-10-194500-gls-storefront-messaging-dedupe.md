## Context

The runtime ownership map already declared:

- `mu-plugins/rusky-storefront-messaging.php`
  as the only owner of storefront-only banners and footer merchandising copy.

But `gastronom-lang-switcher` still duplicated that same block locally.

## Change

Removed the storefront messaging block from:

- `/Users/alexandertartakovsky/Projects/gastronom-migration/gastronom-lang-switcher/gastronom-lang-switcher.php`

Removed local duplicates:

- `gls_free_shipping_banner()`
- `gls_frozen_delivery_notice()`
- `gls_footer_credit()`

Confirmed the surviving owner remains:

- `/Users/alexandertartakovsky/Projects/gastronom-migration/mu-plugins/rusky-storefront-messaging.php`

## Result

The language plugin now stops owning storefront merchandising messages.

This is one completed semantic cut with no live deployment and no new storefront patching.

## Next safe candidate

Continue deduping one ownership block at a time from `gastronom-lang-switcher`:

- shop display block
or
- weighted / commerce block
