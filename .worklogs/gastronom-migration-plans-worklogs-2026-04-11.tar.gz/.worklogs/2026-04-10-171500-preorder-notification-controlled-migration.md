## Context

After helper and state-surface delegation, the next coherent residual boundary in `gastronom-stock-fix.php` was preorder notification and transition orchestration.

This layer already depended on extracted preorder and language helpers, so it was a good low-risk next step.

## What changed

Added a new extraction-ready scaffold:

- `mu-plugins/rusky-preorder-notifications.php`

With new helper names:

- `rpn_send_preorder_created_emails()`
- `rpn_send_weight_confirmation_email()`
- `rpn_mark_weight_confirmed_order_ready()`

Inside `plugins/gastronom-stock-fix/gastronom-stock-fix.php`, these entry points now delegate to `rpn_*` when available:

- `gastronom_send_preorder_created_emails()`
- `gastronom_send_weight_confirmation_email()`
- `gastronom_mark_weight_confirmed_order_ready()`

Fallback implementations remain in-place.

## Why this is safe

- existing hooks and runtime entry points were not changed
- the live control surface still stays under the old `gastronom_*` names
- only ownership of notification/transition logic shifts when the scaffold MU file is present
- if the scaffold MU file is missing, behavior still falls back to the original implementation

## Result

The preorder email/transition layer now has a dedicated ownership target outside the monolith, reducing the amount of cross-cutting business logic trapped in `gastronom-stock-fix.php`.

## Next step

Continue with the last high-value preorder-specific residual block:

- admin confirmation UI and related helper surface
