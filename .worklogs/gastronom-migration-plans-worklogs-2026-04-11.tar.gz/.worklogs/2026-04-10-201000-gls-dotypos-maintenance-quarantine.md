## Context

After storefront messaging, shop display, weighted-commerce, and sorting dedupe cuts, the largest unrelated high-risk surface still bundled into `gastronom-lang-switcher` was the `gls/v1` Dotypos diagnostic / repair REST block.

That block included:

- DB inspection
- option mutation
- Action Scheduler deletion
- plugin file reads
- plugin file writes
- direct patching of Dotypos plugin code

## Change

Created a dedicated quarantine surface:

- `/Users/alexandertartakovsky/Projects/gastronom-migration/mu-plugins/rusky-dotypos-maintenance.php`

Moved the `gls/v1` routes there:

- `gls/v1/dotypos-diag`
- `gls/v1/dotypos-fix`

Removed the same REST block from:

- `/Users/alexandertartakovsky/Projects/gastronom-migration/gastronom-lang-switcher/gastronom-lang-switcher.php`

## Result

- `gastronom-lang-switcher` no longer contains Dotypos diagnostic / repair REST routes
- the dangerous file-write / repair API is now isolated in a maintenance-only MU file
- local language plugin size dropped to `1040` lines

## Important caveat

This was a local architecture-hardening step only.

No live deployment was performed.

The new maintenance MU surface is still high risk by nature and should be treated as temporary operational tooling, not normal storefront runtime.
