# Preorder Status Orchestration Owner Cut

Date: 2026-04-11 10:19:15 +0200

## Scope

Local-only architecture hardening.

No live deploy.

## What changed

- widened `mu-plugins/rusky-weight-preorder.php` with owner-backed compatibility wrappers for preorder status/orchestration entry points:
  - `gastronom_can_reduce_order_stock()`
  - `gastronom_can_restore_order_stock()`
  - `gastronom_prepare_checkout_processed_preorder()`
  - `gastronom_register_await_weight_status()`
  - `gastronom_inject_await_weight_status()`
- added owner-native `rwp_*` implementations for:
  - stock reduce / restore blocking on preorder orders
  - checkout-processed preorder preparation
  - `wc-await-weight` registration
  - insertion of `await-weight` into order status labels
- converted the same orchestration functions in `plugins/gastronom-stock-fix/gastronom-stock-fix.php` into guarded fallback definitions and changed their hooks from anonymous callbacks to named callbacks

## Result

- preorder status transition and stock-control orchestration now live under `rusky-weight-preorder.php`
- `gastronom-stock-fix.php` keeps this slice only as fallback wiring
- remaining monolith residuals are now mostly scattered hook entry points rather than large duplicated helper blocks
