# Storefront Freeze Baseline

## Completed verification block

This block closed only measurable storefront defects and then stops further live storefront patching.

## Baseline files saved

- `/Users/alexandertartakovsky/Projects/gastronom-migration/_snapshots/2026-04-10-baseline/home-ru.html`
- `/Users/alexandertartakovsky/Projects/gastronom-migration/_snapshots/2026-04-10-baseline/category-ru.html`
- `/Users/alexandertartakovsky/Projects/gastronom-migration/_snapshots/2026-04-10-baseline/product-ru.html`
- `/Users/alexandertartakovsky/Projects/gastronom-migration/_snapshots/2026-04-10-baseline/cart-ru.html`
- `/Users/alexandertartakovsky/Projects/gastronom-migration/_snapshots/2026-04-10-baseline/checkout-ru-final.html`
- `/Users/alexandertartakovsky/Projects/gastronom-migration/_snapshots/2026-04-10-baseline/cart-ru-after-empty-shell-fix.html`
- `/Users/alexandertartakovsky/Projects/gastronom-migration/_snapshots/2026-04-10-baseline/checkout-ru-after-empty-shell-fix.html`

## Step results

### 1. Checkout language persistence

Status: success

Verified:

- `https://ruskyobchod.sk/checkout/?lang=ru` returns `302`
- redirect location is `https://ruskyobchod.sk/cart/?lang=ru`
- response sets `gastronom_lang=ru`
- final empty-cart page renders Russian text

### 2. Empty cart / checkout shell cleanup

Status: success

Scope:

- only empty cart shell
- only empty checkout shell after redirect
- only removal of visual theme wrappers:
  - `bradcrumbs`
  - `vw-page-title`

Verified in saved post-fix snapshots:

- `wc-empty-cart-message` remains
- `cart-empty` remains
- `bradcrumbs` markup block is gone
- `vw-page-title` markup block is gone

Note:

- `.bradcrumbs{text-align:start;}` still exists in CSS output and is not treated as a defect

### 3. Front-page skip-link malformed duplication

Status: failed and reverted

The attempted live-safe patch did not change the malformed `skip-link` output.
That step was reverted immediately and is not part of the freeze baseline.

## Live status at freeze point

- homepage: `200`
- `wp-login.php`: `200`
- original `gastronom-lang-switcher` remains active
- emergency `rusky-language-switcher-lite.php` remains disabled
- live storefront patching is now frozen

## Immediate next mode

Return to architecture hardening only in the local codebase.
No more live storefront changes unless a new selling-blocking regression appears.
