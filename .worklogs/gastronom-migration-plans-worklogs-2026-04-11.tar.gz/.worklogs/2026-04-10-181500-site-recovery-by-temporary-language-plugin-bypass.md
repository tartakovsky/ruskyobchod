## Context

The live site entered a site-wide `503` state during the session.

Observed scope:

- homepage returned `503`
- `wp-login.php` returned `503`
- direct CLI bootstrap through `wp-load.php` stalled inside WordPress bootstrap

## What was confirmed

- WordPress core and database were still reachable via `wp-cli` with `--skip-plugins --skip-themes`
- `wp-cli --skip-plugins option get siteurl` worked
- this isolated the active failure surface to normal plugin runtime rather than database or core bootstrap itself

## Recovery action

The active runtime owner on live was not `rusky-runtime-shim.php`.

Live was still using:

- `wp-content/mu-plugins/rusky-disable-far.php`

An emergency minimal bypass was applied there to filter out:

- `real-time-find-and-replace/real-time-find-and-replace.php`
- `gastronom-lang-switcher/gastronom-lang-switcher.php`

## Result

After uploading the one changed MU file:

- homepage returned `200`
- `wp-login.php` returned `200`
- `apply_filters('option_active_plugins', get_option('active_plugins'))` no longer included `gastronom-lang-switcher`

## Working conclusion

The immediate site-wide outage was in the active plugin runtime path and the live recovery came from temporarily bypassing `gastronom-lang-switcher`.

This does not yet prove the exact internal root cause inside the plugin, but it does prove the emergency recovery surface.

## Next rule

Do not re-enable `gastronom-lang-switcher` on live until its failure path is isolated in a controlled way.

## Follow-up storefront stabilization

After the emergency bypass restored `200` responses, a second live-safe MU surface was used to recover the storefront shell without re-enabling the failing plugin:

- `wp-content/mu-plugins/rusky-language-switcher-lite.php`

That emergency file now owns only:

- `?lang=` / cookie state
- switcher output with active button state
- reuse of `gls-style.css`
- front-page-only output cleanup

Verified live outcomes after incremental uploads and `php -l` checks on the remote copy:

- homepage still returned `200` after each upload
- duplicated front-page bilingual blocks were removed
- RU and SK menu labels were normalized
- RU and SK `screen-reader-text` / `aria-label` menu strings were normalized
- skip-link duplication on the front page was removed
- front-page search/account/cart chrome was normalized for the active language
- RU isolated Chrome check showed:
  - active `RU` switcher state
  - no duplicated first-screen headings
  - normalized top header controls

Remaining caution:

- `gastronom-lang-switcher` is still bypassed on live
- emergency storefront cleanup is intentionally limited to the lite MU surface
- checkout/cart/category/detail-page translation cleanup still needs separate controlled passes
