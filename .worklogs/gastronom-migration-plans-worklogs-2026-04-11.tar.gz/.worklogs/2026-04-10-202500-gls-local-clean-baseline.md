## Context

After the local ownership cuts on `gastronom-lang-switcher`, the file was compared again with:

- `/Users/alexandertartakovsky/Projects/gastronom-migration/gastronom-lang-switcher.live-current.php`

## Result

The local `gastronom-lang-switcher` is now reduced to a mostly language/runtime shell.

Current size:

- `1038` lines

After the storefront messaging, shop display, commerce, sorting, and Dotypos-maintenance extractions, the remaining diff versus `live-current` is now limited to two small lines:

1. parenthesized `isset($_GET['action']) && $_GET['action'] === 'elementor'`
2. XML declaration cleanup regex inside `gls_strip_inactive_language_blocks()`

## Meaning

This is the first local baseline in the session where the language plugin is no longer carrying:

- storefront merchandising messages
- shop display tuning
- weighted-product mechanics
- pickup-note cart UX
- product sorting ownership
- Dotypos diagnostic / repair REST routes

## Caveat

This is still a local hardening baseline only.

No live deployment was performed from this cleaned plugin state.
