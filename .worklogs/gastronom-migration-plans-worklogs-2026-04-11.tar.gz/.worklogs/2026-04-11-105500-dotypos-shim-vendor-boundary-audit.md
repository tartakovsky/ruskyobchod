# Dotypos Shim Vendor Boundary Audit

Date: 2026-04-11

## Scope

Re-check the two unresolved Dotypos shim wrappers and determine whether repo-local evidence is now sufficient to delete them.

## Target wrappers

- `gastronom_apply_dotypos_stock_to_wc_product()`
- `gastronom_resolve_dotypos_order_sync_quantity()`

## Findings

### Repo-local call sites

- direct repo-local references still exist only in:
  - `/Users/alexandertartakovsky/Projects/gastronom-migration/mu-plugins/rusky-dotypos-stock-bridge.php`
  - `/Users/alexandertartakovsky/Projects/gastronom-migration/plugins/gastronom-stock-fix/gastronom-stock-fix.php`
  - snapshot copies under `_snapshots/`

### Vendor boundary visibility

- the workspace does not contain the Dotypos plugin source or another vendor runtime source that could prove whether these wrappers are invoked indirectly
- repo-local grep shows Dotypos usage only through:
  - `Dotypos::instance()`
  - `dotyposService->updateProductStock(...)`
  - `dotyposService->getProductOnWarehouse(...)`
  - `remove_action('woocommerce_update_product', [$dotypos, 'handle_product_updated'], 10)`

### Consequence

- there is still no safe local proof that the two shim wrappers are fully dead
- there is also no local proof that they are actively used by vendor runtime wiring
- this keeps them in the same retention bucket as before:
  compatibility shim until a separate live/vendor audit is performed

## Decision

- do not delete:
  - `gastronom_apply_dotypos_stock_to_wc_product()`
  - `gastronom_resolve_dotypos_order_sync_quantity()`
- treat them as the last unresolved shell-only bridge points on the Dotypos boundary

## Practical result

- local architecture hardening is no longer blocked by missing extraction
- the next uncertainty is external runtime validation, not more repo surgery
