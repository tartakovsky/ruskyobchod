# Регистрация домена gastronom-bratislava.sk

**Date:** 2026-03-16 23:15
**Scope:** Домены, Websupport, регистрация

## Summary
Зарегистрирован домен gastronom-bratislava.sk на Websupport.sk. Оплачен картой B.A.A.B. s.r.o. за 12,18 € (9,90 + DPH). Доменный профиль: B.A.A.B. s.r.o., Zámocká 5, 81101 Bratislava, IČO 43784402.

## Context & Problem
Нужен новый домен со словом "gastronom" для магазина. gastronom.sk занят. Hostinger не поддерживает .sk домены. Нужен словацкий регистратор.

## Decisions Made

### Выбор регистратора
- **Chose:** Websupport.sk
- **Why:** У пользователя уже есть аккаунт (от VeraVitis s.r.o.). Active24 требовал создание нового аккаунта на чешской платформе. Цена одинаковая — 9,90 €/год.

### Сравнение цен .sk регистраторов
- Exohosting: 4,99 € (1 год)
- Websupport: 9,90 € (1 год), 16,90 € (продление)
- Active24: 9,90 € (1 год), 16,90 € (продление)
- FORPSI: 11,90 € (1 год), 12,56 € (продление)

### Доменный профиль
- **Chose:** Новый профиль B.A.A.B. s.r.o. (IČO 43784402)
- **Why:** Аккаунт Websupport на VeraVitis, но домен нужен на B.A.A.B. Старый профиль давал ошибку, создан новый.

### ruskyobchod.sk — регистратор
- **Chose:** Подтверждено по WHOIS: зарегистрирован на Active24 (ACTI-0024), не на Websupport
- **Why:** Nameservers domenator.com (Hostenko). Пользователь думал что на Websupport.

## Open Questions
- Настройка DNS gastronom-bratislava.sk → Hostinger (при запуске)
- 301 redirect с ruskyobchod.sk на gastronom-bratislava.sk (при переходе)
- Перенос ruskyobchod.sk DNS на Hostinger (для запуска сайта)
