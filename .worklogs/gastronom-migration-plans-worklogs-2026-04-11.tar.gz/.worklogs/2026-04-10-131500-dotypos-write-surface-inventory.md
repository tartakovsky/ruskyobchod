## Context

Continuing the architecture hardening sequence after restoring context from the saved April 10 artifacts and re-reading the older handoff pack from `Downloads/handoff.zip`.

Following the handoff rules:

- repo remains the control surface
- no production-first edits
- architecture work is being split into documented semantic passes

## What was done

1. Re-read the older handoff pack sections that define workflow and the architecture rebuild direction.
2. Revalidated the current local runtime hardening state:
   - `rusky-runtime-shim.php` is now the single local owner of `option_active_plugins`
   - duplicate `rusky-disable-far.php` has been removed locally
   - custom runtime inventory was regenerated
3. Performed a read-only inventory pass over:
   - `plugins/gastronom-stock-fix/gastronom-stock-fix.php`

## Findings

- Direct Dotypos stock writes inside `gastronom-stock-fix.php` are limited to two code paths:
  - confirmed preorder deduction
  - confirmed preorder restore
- Both writes are guarded and tied only to `_gastronom_weight_preorder` items with confirmed actual weight.
- The file also contains a higher-risk integration override:
  - removal of vendor `handle_product_updated` hook on `woocommerce_update_product`
- Two Dotypos-intent helper functions exist but are not referenced elsewhere by name in the current repo snapshot:
  - `gastronom_apply_dotypos_stock_to_wc_product()`
  - `gastronom_resolve_dotypos_order_sync_quantity()`

## Artifacts

- Added:
  - `/Users/alexandertartakovsky/Projects/gastronom-migration/.plans/2026-04-10-gastronom-stock-fix-dotypos-write-surface.md`

## Next step

Inventory the preorder-weight state machine separately so the future extraction boundary is clean:

- order creation
- Woo-only reservation
- `await-weight`
- manager confirmation
- restore behavior
