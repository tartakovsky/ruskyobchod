# 2026-04-11 01:25 order page compat owner cut

## Scope

Local-only hardening.

No live deploy in this step.

## Goal

Apply the same guarded-owner pattern to the order-page language surface that was already used for order-language helpers.

## Changes

Expanded:

- `/Users/alexandertartakovsky/Projects/gastronom-migration/mu-plugins/rusky-order-page-language.php`

It now exposes guarded compatibility wrappers for:

- `gastronom_get_context_order_for_frontend_language()`
- `gastronom_normalize_order_page_html()`

Reduced monolith ownership in:

- `/Users/alexandertartakovsky/Projects/gastronom-migration/plugins/gastronom-stock-fix/gastronom-stock-fix.php`

Those same functions are now wrapped in `if (!function_exists(...))`, so the MU owner can define them first and the plugin keeps only guarded fallback definitions.

## Outcome

The order-page language surface now follows the same pattern as the order-language helper surface:

- owner file can become the real source of truth
- monolith remains compatible but is no longer the only definition site

## Next logical cut

Continue with adjacent owner-backed preorder/order helpers only, still local-only unless a new storefront regression is reproduced in browser.
