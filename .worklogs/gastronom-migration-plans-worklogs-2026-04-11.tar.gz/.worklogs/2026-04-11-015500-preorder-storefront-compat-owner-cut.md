# 2026-04-11 01:55 preorder storefront compat owner cut

## Scope

Local-only hardening.

No live deploy in this step.

## Goal

Move the preorder storefront compatibility surface closer to the real storefront owner instead of keeping `gastronom_*` storefront functions defined only in the monolith.

## Changes

Expanded:

- `/Users/alexandertartakovsky/Projects/gastronom-migration/mu-plugins/rusky-preorder-storefront.php`

It now exposes guarded compatibility wrappers for:

- `gastronom_quantity_input_args()`
- `gastronom_add_to_cart_quantity()`
- `gastronom_add_to_cart_validation()`
- `gastronom_before_calculate_totals()`
- `gastronom_get_item_data()`
- `gastronom_render_single_product_note()`
- `gastronom_render_cart_notice()`
- `gastronom_available_payment_gateways()`
- `gastronom_price_html()`
- `gastronom_checkout_create_order()`
- `gastronom_checkout_create_order_line_item()`

Reduced monolith ownership in:

- `/Users/alexandertartakovsky/Projects/gastronom-migration/plugins/gastronom-stock-fix/gastronom-stock-fix.php`

Those same storefront functions are now wrapped in `if (!function_exists(...))`, so the MU owner can define them first and the monolith becomes guarded fallback.

## Outcome

The preorder storefront/runtime slice now follows the same guarded-owner pattern already applied to:

- order-language helpers
- order-page helpers
- commerce-adjustment helpers

This makes the storefront ownership boundary more explicit and shrinks the monolith's hard ownership area further.
