# Sellable Storefront Freeze Check

Date: 2026-04-11

## Scope

Freeze-check the current live RU storefront paths without introducing any new live changes.

## HTTP checks

- `https://ruskyobchod.sk/?lang=ru` -> `200`
- `https://ruskyobchod.sk/kategoria-produktu/sneki-snacky/?lang=ru` -> `200`
- `https://ruskyobchod.sk/produkt/barbaris-40-g/?lang=ru` -> `200`
- `https://ruskyobchod.sk/cart/?lang=ru` -> `200`
- `https://ruskyobchod.sk/checkout/?lang=ru` -> `302` -> `https://ruskyobchod.sk/cart/?lang=ru`

## Browser verification

- homepage RU is visually clean and RU-only
- category RU is sellable and the sorting dropdown shows `По алфавиту`
- product RU is sellable, product chrome is in RU, add-to-cart path is present
- cart RU still renders
- checkout RU still redirects back to cart with `?lang=ru`

## Residuals

- category and product snapshots still expose duplicated skip-link text:
  `Перейти к содержимому Перейти к содержимому`
- this is treated as a non-blocking residual for this freeze-check because the sellable storefront paths remain usable and no new live patch is justified in the same cycle

## Result

- live storefront remains sellable on the key RU paths
- no new live deploy was performed during this freeze-check
- safe next move remains local-only architecture hardening unless a reproduced live regression appears
