# Order Page Wrapper Collapse

## Scope

Local architecture hardening only.

No live deploy.

## Goal

Remove another duplicated fallback body from:

- `/Users/alexandertartakovsky/Projects/gastronom-migration/plugins/gastronom-stock-fix/gastronom-stock-fix.php`

where a dedicated owner already exists.

## Change

Collapsed these monolith functions to thin wrappers:

- `gastronom_get_context_order_for_frontend_language()`
- `gastronom_normalize_order_page_html()`

They now delegate to the dedicated owner:

- `/Users/alexandertartakovsky/Projects/gastronom-migration/mu-plugins/rusky-order-page-language.php`

and otherwise return a safe neutral result:

- `null`
- unchanged `$html`

## Result

The order-page language block now has less duplicated behavior in the monolith and clearer ownership in `rusky-order-page-language.php`.
