## Context

After moving stock normalization, language helpers, preorder core, and Dotypos preorder bridge ownership toward dedicated scaffold surfaces, the next low-risk residual surface was frontend order-page language handling.

This logic was still embedded inside `gastronom-stock-fix.php`, even though it is not part of stock mutation itself.

## What changed

Added a new extraction-ready scaffold:

- `mu-plugins/rusky-order-page-language.php`

With new helper names:

- `ropl_context_order()`
- `ropl_normalize_order_page_html()`

Inside `plugins/gastronom-stock-fix/gastronom-stock-fix.php`, these entry points now delegate to `ropl_*` when available:

- `gastronom_get_context_order_for_frontend_language()`
- `gastronom_normalize_order_page_html()`

Fallback implementations remain in-place.

## Why this is safe

- no hook wiring changed
- all existing runtime entry points stay under the old `gastronom_*` names
- the new file only owns helper logic, not output buffering or redirects
- if the scaffold MU file is missing, behavior still falls back to the original implementation

## Result

The monolithic stock/preorder plugin now has a cleaner ownership target for frontend order-language rewriting without changing the active runtime graph.

## Next step

Review the remaining residual surfaces in `gastronom-stock-fix.php` and keep separating:

- admin confirmation UI helpers
- preorder state-transition helpers
- email rendering / notification helpers
