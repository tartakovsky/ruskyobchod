## User-reported storefront regressions

Reported by the user during the current hardening session.

These should be handled as explicit follow-up checks/fixes and not left implicit inside broader architecture work.

## Reported issues

- language switcher button does not show the active state clearly after click
- language switcher layout is not inline / looks broken
- free-delivery banner for orders over 100 EUR inside the categories area is not translated correctly
- footer has an ugly single-letter line break
- checkout:
  - "Ваш заказ" area is translated partially / awkwardly
  - payment-method labels are translated partially / awkwardly
- cart:
  - product list is translated
  - adjacent/additional messages in the same area are not translated

## Handling note

Treat these as separate storefront/localization regressions.

Do not fold them blindly into architecture hardening or broad runtime surgery.

Preferred sequence after stabilizing runtime:

1. reproduce each issue on live
2. map each issue to the owning surface
3. patch the smallest responsible file
4. verify RU and SK explicitly after each fix
