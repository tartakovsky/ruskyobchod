## Context

Continuing the main hardening track according to the handoff rules:

- smallest safe surface first
- no broad behavior change during architecture cleanup
- no mixed integration re-enable

After extracting the order-language helper scaffold, the next safest step was to prepare the preorder core as a separate local surface without migrating live hooks yet.

## What was done

Added:

- `/Users/alexandertartakovsky/Projects/gastronom-migration/mu-plugins/rusky-weight-preorder.php`

## What is inside

Scaffold-only preorder core with `rwp_*` names:

- product enable/min/max/avg helpers
- price-per-kg helper
- reserved quantity calculation
- piece-capacity calculation
- local piece-stock application
- item confirmation check
- order-level confirmation requirement check

## Why this is safe

- no current hooks were redirected
- no order flow changed
- no checkout/admin runtime path changed
- no function-collision risk with the existing `gastronom_*` code

## Why this matters

This is the first real code surface for the future `rusky-weight-preorder.php` extraction.
It reduces the amount of logic that still has to be rediscovered when the actual hook migration begins.

## Next step

Choose the first low-risk call-site migration from `gastronom_*` to `rwp_*`, or continue building the remaining preorder scaffold before any live wiring changes.
