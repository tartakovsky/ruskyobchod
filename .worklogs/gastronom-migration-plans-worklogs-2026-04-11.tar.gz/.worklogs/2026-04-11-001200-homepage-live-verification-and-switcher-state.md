# 2026-04-11 00:12 homepage live verification and switcher state

## Scope

Live quick-fix only, following `handoff.zip` rules:

- one file
- one deploy
- immediate browser verification in the broken logged-in homepage path

Target file:

- `/Users/alexandertartakovsky/Projects/gastronom-migration/gastronom-lang-switcher/gastronom-lang-switcher.php`

## Changes

1. Removed the logged-in frontend exclusion from `gls_is_sensitive_runtime_context()`.
   Result: homepage normalization now runs for ordinary logged-in frontend requests.

2. Added current-language active class to the language switcher output.
   Result: `RU`/`SK` now exposes a visible active state through the existing `.gls-btn.active` CSS.

3. Broadened front-page `skip-link` normalization to replace any `skip-link` anchor targeting `#maincontent`.
   Result: malformed duplicated `skip-link` text is collapsed to a single localized label.

## Live deployment

Each change was deployed as the single changed file only:

- live path:
  `/home/u595644545/domains/ruskyobchod.sk/public_html/wp-content/plugins/gastronom-lang-switcher/gastronom-lang-switcher.php`

Backups created on server:

- `gastronom-lang-switcher.php.pre-logged-in-homefix-2026-04-10-1958`
- `gastronom-lang-switcher.php.pre-active-state-2026-04-11-0006`
- `gastronom-lang-switcher.php.pre-skiplink-2026-04-11-0010`

## Verification

Verified in Chrome DevTools on:

- `https://ruskyobchod.sk/?lang=ru`

Observed results after reload:

- homepage no longer shows RU and SK hero/text blocks together
- homepage content renders RU-only in the logged-in browser path
- switcher state is correct:
  - RU class: `gls-btn gls-btn-ru active`
  - SK class: `gls-btn gls-btn-sk`
  - RU computed background: `rgb(26, 58, 92)`
  - RU computed text color: `rgb(255, 255, 255)`
- `skip-link` now renders as:
  - `<a class="screen-reader-text skip-link" href="#maincontent">Перейти к содержимому</a>`

## Outcome

The main homepage regression reported by the user is now closed in the actual broken contour:

- logged-in homepage no longer renders bilingual hero/body content
- language switcher has a visible active state
- `skip-link` duplication is removed

Remaining storefront issues should be handled one at a time with the same live discipline.
