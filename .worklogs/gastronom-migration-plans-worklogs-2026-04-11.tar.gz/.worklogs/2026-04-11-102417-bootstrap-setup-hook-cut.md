# Bootstrap Setup Hook Cut

Date: 2026-04-11 10:24:17 +0200

## Scope

Local-only architecture hardening.

No live deploy.

## What changed

- removed the remaining anonymous bootstrap/setup hooks from the top of `plugins/gastronom-stock-fix/gastronom-stock-fix.php`
- converted them to named guarded callbacks for:
  - decimal stock amount setup
  - stock notification option disable
  - stock email action disable
  - Dotypos `handle_product_updated` detach
  - REST decimal stock schema adjustment
  - stock reconciliation on direct Woo stock changes
  - stock reconciliation on REST inserts
  - stock reconciliation on `_stock` meta writes
  - one-time stock repair run
- converted `mu-plugins/rusky-dotypos-maintenance.php` REST route registration from anonymous callback to named `rdm_register_rest_routes()` and added a guarded compatibility wrapper

## Result

- the top of `gastronom-stock-fix.php` is now named-hook based instead of anonymous-hook based
- bootstrap/setup behavior became easier to diff and safer to trim further
- no live behavior changed because nothing was deployed
