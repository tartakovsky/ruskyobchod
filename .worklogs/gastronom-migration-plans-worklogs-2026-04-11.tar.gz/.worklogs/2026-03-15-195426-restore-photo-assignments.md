# Восстановление фотографий товаров из маппинга

**Date:** 2026-03-15 19:54
**Scope:** WooCommerce products photo assignments, restore_photos.py, restore_photos_by_name.py

## Summary
Restored photo assignments to 608 out of 724 WooCommerce products using the saved mapping file `photo_mapping_2026-03-14.json`. The mapping contained 603 products with images, but product IDs had changed since the mapping was saved, requiring name-based matching.

## Context & Problem
Product images were lost (likely due to a re-import or plugin action). A mapping file with 603 products and their image assignments was saved on 2026-03-14. However, product IDs in WooCommerce had changed — old IDs (7897-9892) no longer existed, current IDs are 10007-10805.

## Decisions Made

### Name-based matching instead of ID-based
- **Chose:** Match products by normalized name instead of WC product ID
- **Why:** 584 out of 603 product IDs in the mapping no longer existed in WooCommerce

### Three-pass matching strategy
- **Chose:** Exact normalized match -> homoglyph-normalized match -> fuzzy difflib match (0.85 cutoff)
- **Why:** Product names had minor differences: separator changes (`/` vs `.` vs ` / `), Cyrillic/Latin homoglyph confusion, whitespace differences

### Excluded 5 false fuzzy matches
- **Chose:** Manually excluded IDs 10313, 10604, 10246, 10548, 10781 from fuzzy matching
- **Why:** These matched to wrong products (different weights, different product entirely)

## Results
- Pass 1 (exact + ID overlap): 19 products updated
- Pass 2 (exact name match after separator normalization): 533 products updated
- Pass 3 (homoglyph match): 1 product updated
- Pass 4 (fuzzy match, 0.85 cutoff): 32 products updated
- **Total: 608/724 products now have images**
- Remaining 116 products without images: genuinely new products or substantially renamed ones not in the mapping

## Open Questions / Future Considerations
- 116 products still lack images — these need manual photo assignment or a different data source
- The mapping file should be re-saved after this restoration as a new golden snapshot
