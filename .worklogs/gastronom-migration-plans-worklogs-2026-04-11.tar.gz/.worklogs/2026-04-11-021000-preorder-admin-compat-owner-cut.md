# 2026-04-11 02:10 preorder admin compat owner cut

## Scope

Local-only hardening.

No live deploy in this step.

## Goal

Apply the same guarded-owner pattern to the preorder admin surface so the MU owner can define the compatibility layer first and the monolith only remains as fallback.

## Changes

Expanded:

- `/Users/alexandertartakovsky/Projects/gastronom-migration/mu-plugins/rusky-preorder-admin.php`

It now exposes guarded compatibility wrappers for:

- `gastronom_render_product_preorder_fields()`
- `gastronom_save_product_preorder_fields()`
- `gastronom_render_weight_confirmation_box()`
- `gastronom_order_screen_ids()`

Reduced monolith ownership in:

- `/Users/alexandertartakovsky/Projects/gastronom-migration/plugins/gastronom-stock-fix/gastronom-stock-fix.php`

Those same functions are now wrapped in `if (!function_exists(...))`, so the MU owner can define them first and the plugin becomes guarded fallback in that admin surface as well.

## Outcome

The preorder admin surface now matches the same ownership pattern already applied to:

- order-language helpers
- order-page helpers
- preorder storefront helpers
- commerce adjustments

This continues shrinking the monolith's hard ownership area without changing live behavior.
