# Wrapper Overlap Audit

Date: 2026-04-11 10:37:44 +0200

## Scope

Local-only audit of guarded `gastronom_*` compatibility wrappers across owner files in:

- `mu-plugins/`

## Result

No duplicate guarded wrapper definitions were found across owner files.

That means:

- each `gastronom_*` compatibility wrapper currently has a single owner file in `mu-plugins/`
- the monolith fallback is not competing with multiple owner definitions for the same wrapper name

## Verified spot checks

Confirmed single-owner placement for recently suspicious wrappers:

- `gastronom_render_product_preorder_fields()` -> `rusky-preorder-admin.php`
- `gastronom_save_product_preorder_fields()` -> `rusky-preorder-admin.php`
- `gastronom_add_cod_fee()` -> `rusky-commerce-adjustments.php`
- `gastronom_gateway_description()` -> `rusky-commerce-adjustments.php`
- `gastronom_render_checkout_payment_refresh_script()` -> `rusky-commerce-adjustments.php`
- `gastronom_weight_preorder_enabled()` -> `rusky-weight-preorder.php`

## Practical implication

The residual risk is no longer duplicate wrapper ownership.

The remaining risk is only:

- whether a wrapper should stay as compatibility shim
- whether some wrappers can later be deleted after full live/vendor reference audit
