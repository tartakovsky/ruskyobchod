# Custom Runtime Inventory Refresh

Date: 2026-04-11

## Scope

Refresh the runtime inventory so it reflects the current local owner split instead of the old fixed file list.

## What changed

- updated `/Users/alexandertartakovsky/Projects/gastronom-migration/inventory_custom_runtime.py`
- replaced the old hardcoded MU subset with dynamic discovery of `mu-plugins/rusky-*.php`
- kept the two non-MU control points in the inventory:
  - `gastronom-lang-switcher.live-current.php`
  - `plugins/gastronom-stock-fix/gastronom-stock-fix.php`
- regenerated:
  - `/Users/alexandertartakovsky/Projects/gastronom-migration/.plans/2026-04-10-custom-runtime-inventory.json`
  - `/Users/alexandertartakovsky/Projects/gastronom-migration/.plans/2026-04-10-custom-runtime-inventory.md`

## Result

- the inventory now covers `20` current runtime files
- all new `rusky-*` owner files are now visible in the control-surface audit
- this removes the stale blind spot before the next integration step
