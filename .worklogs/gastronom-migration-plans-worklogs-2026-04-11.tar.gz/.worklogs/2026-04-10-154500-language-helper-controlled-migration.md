## Context

Continuing the same controlled-migration pattern after moving generic stock normalization ownership toward `rsn_*`.

The next lowest-risk boundary was the order/preorder language helper surface.

## What changed

Inside `plugins/gastronom-stock-fix/gastronom-stock-fix.php`, these helper entry points now delegate to `rslh_*` when available:

- `gastronom_current_lang()`
- `gastronom_order_lang()`
- `gastronom_tt()`
- `gastronom_t()`
- `gastronom_locale_for_order()`
- `gastronom_with_order_locale()`
- `gastronom_split_bilingual_title()`
- `gastronom_localize_title()`
- `gastronom_localize_order_label()`

Fallback implementations remain in-place.

## Why this is safe

- existing call sites were not rewritten
- no hook wiring changed
- runtime still enters through the old `gastronom_*` function names
- if the scaffold MU file is missing, behavior still falls back to the old implementation

## Result

The language-helper ownership has now started shifting out of the junk-drawer file using the same low-risk delegation pattern as stock normalization.

## Next step

Continue with the preorder core helper surface:

- move `gastronom_weight_preorder_*` helper ownership toward `rwp_*`
- still without migrating stateful hooks yet
