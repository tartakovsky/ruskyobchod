## Context

The runtime ownership map already assigns weighted-product and pickup-note behavior to:

- `/Users/alexandertartakovsky/Projects/gastronom-migration/mu-plugins/rusky-commerce-adjustments.php`

But `gastronom-lang-switcher` still duplicated the same WooCommerce mechanics locally.

## Change

Removed the weighted / commerce duplicate block from:

- `/Users/alexandertartakovsky/Projects/gastronom-migration/gastronom-lang-switcher/gastronom-lang-switcher.php`

Removed local duplicates:

- weighted decimal add-to-cart quantity fix
- `woocommerce_stock_amount -> floatval`
- weighted cart update validation
- decimal stock REST schema override
- decimal stock pre-save coercion
- `_gls_weighted` admin field/save hooks
- weighted quantity input args
- weighted add-to-cart validation
- weighted price suffix
- cart pickup-note output

Confirmed the surviving owner remains:

- `/Users/alexandertartakovsky/Projects/gastronom-migration/mu-plugins/rusky-commerce-adjustments.php`

## Result

`gastronom-lang-switcher` no longer owns weighted-product or pickup-note behavior.

This was another local-only ownership cleanup with no live deployment.

## Remaining high-risk block still inside the language plugin

- `gls/v1` Dotypos diagnostic / repair REST routes

That block remains the most dangerous unrelated surface still bundled into the language plugin.
