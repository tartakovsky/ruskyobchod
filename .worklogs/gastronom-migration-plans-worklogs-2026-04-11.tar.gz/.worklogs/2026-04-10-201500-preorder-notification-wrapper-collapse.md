# Preorder Notification Wrapper Collapse

## Scope

Local architecture hardening only.

No live deploy.
No storefront change.

## Goal

Reduce duplicated notification / transition bodies still left in:

- `/Users/alexandertartakovsky/Projects/gastronom-migration/plugins/gastronom-stock-fix/gastronom-stock-fix.php`

after the notification owner file had already been created.

## Change

Collapsed these legacy monolith entry points into thin wrappers only:

- `gastronom_send_preorder_created_emails()`
- `gastronom_send_weight_confirmation_email()`
- `gastronom_mark_weight_confirmed_order_ready()`

They now simply delegate to:

- `rpn_send_preorder_created_emails()`
- `rpn_send_weight_confirmation_email()`
- `rpn_mark_weight_confirmed_order_ready()`

owned by:

- `/Users/alexandertartakovsky/Projects/gastronom-migration/mu-plugins/rusky-preorder-notifications.php`

## Result

The notification / transition block is no longer duplicated in two places.

`gastronom-stock-fix.php` still preserves the old entry points for hook compatibility, but the behavior body now lives in the dedicated owner file only.
