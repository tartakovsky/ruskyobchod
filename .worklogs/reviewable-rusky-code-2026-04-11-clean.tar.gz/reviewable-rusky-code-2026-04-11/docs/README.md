# Reviewable Rusky Code Bundle

Date: 2026-04-11

This bundle contains the actual WordPress code files from the working workspace.

It exists because the audited public repo did not contain the implementation that the notes described.

Repo-style target paths are already laid out under:

- `wordpress/wp-content/plugins/gastronom-lang-switcher/`
- `wordpress/wp-content/plugins/gastronom-stock-fix/`
- `wordpress/wp-content/mu-plugins/`

Files under `external/` are supporting reconciliation artifacts, not repo-target WordPress paths.
