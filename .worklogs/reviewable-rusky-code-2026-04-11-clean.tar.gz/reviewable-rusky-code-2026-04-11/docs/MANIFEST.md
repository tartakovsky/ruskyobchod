# Manifest

Source workspace:

- `/Users/alexandertartakovsky/Projects/gastronom-migration`

Repo-target code included:

- `wordpress/wp-content/plugins/gastronom-lang-switcher/gastronom-lang-switcher.php`
- `wordpress/wp-content/plugins/gastronom-lang-switcher/gls-style.css`
- `wordpress/wp-content/plugins/gastronom-stock-fix/gastronom-stock-fix.php`
- `wordpress/wp-content/mu-plugins/*.php`

External reconciliation files included:

- `external/gastronom-lang-switcher.live-current.php`
- `external/footer.live.php`
- `external/inventory_custom_runtime.py`
- `external/2026-04-10-architecture-hardening-handoff.md`
- `external/2026-04-11-integration-readiness-verdict.md`
